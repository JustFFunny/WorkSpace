# UTPinYinHelper
通过拼音去匹配汉字，简单来说，就是拼音搜索

## 如何使用UTPinYinHelper
* cocoapods导入：`暂不支持`
* 手动导入：
    * 将`UTPinYinHelper`文件夹中的所有文件拽入项目中
    * 导入主头文件：`#import "UTPinYinHelpe.h`

## 演示
![(演示)](https://github.com/tangzhengyue/UTPinYinHelper/blob/master/demo.gif)