// Leaveword.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[])
{
	char *szGetCookie = getenv("HTTP_COOKIE");
	printf("Content-type:text/html\n\n");
	if(NULL == szGetCookie)
	{
		printf("<meta http-equiv=\"Refresh\" content=\"3;URL=/Forum/Load.html\" />");
		printf("<div align=\"center\">");
		printf("<table width=\"429\" height=\"82\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
		printf("<tr>");
		printf("<td width=\"425\" height=\"29\" align=\"center\" valign=\"middle\" bgcolor=\"#FFFFCC\"><span class=\"STYLE2\">");
		printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;��Ҫ��¼�ſ���ִ�д˲���!3��󽫻�ת����Ӧҳ��...</span></td>");
		printf("</tr><tr>");
		printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
		printf("<a href=\"/Forum/Load.html\" class=\"STYLE2\">������������û���Զ���ת,�������</a></td>");
		printf("</tr>");
		printf("</table>");
		printf("</div>");
		return 0;
	}
	char szCookieDecode[256] = {'\0'};
	char szName[256] = {'\0'};
	Decode(szGetCookie, strlen(szGetCookie), szCookieDecode);
	sscanf(szCookieDecode, "name=%[^'\0']", szName);	
	PrintHeader(szName);
	PrintTail();
	return 0;
}


void PrintHeader(char *szCookieName)
{
	printf("<html>");
	printf("<head>");
	printf("<title>�����������̳</title>");
	printf("<style type=\"text/css\">");
	printf("<!--.STYLE1 {font-size: 14px}.STYLE8 {font-size: 16px}");
	printf(".STYLE10 {font-size: 14px; font-weight: bold; }.STYLE12 {font-size: 18}.STYLE13 {font-size: 18px}");
	printf("--></style>");
	printf("</head>");
	printf("<body>");
	printf("<div align=\"right\">");
	printf("<p><a href=\"/Forum/Forum.html\"><img src=\"/Images/logo.gif\" width=\"185\" height=\"74\" align=\"left\"  border=\"0\"/></a>");
	printf("<img src=\"/Images/www.jpg\" width=\"150\" height=\"91\" /></p>");
	printf("</div>");
	printf("<DIV style=\"LEFT: 11px; POSITION: absolute; TOP: 125px; width: 1369px;\">");
	printf("<TABLE cellSpacing=0 cellPadding=0 width=1365 border=0>");
	printf("<TBODY><TR><TD width=\"1380\">");
	printf("<hr width=\"1390\" align=\"left\">");
	printf("<A href=\"/cgi-bin/ControlPanel.cgi\" target=_parent>�������</A-->&nbsp;&nbsp;");
	printf("<span class=\"STYLE8\">&nbsp;&nbsp;</span><A href=\"http://www.google.com\" target=_blank>��վ���û�������</A>&nbsp;&nbsp;");
	printf("<A href=\"http://www.163.com\" target=_blank>������д��������</A>&nbsp;&nbsp;");
	printf("<A href=\"http://www.hao123.com\" target=_blank>������д��������</A>&nbsp;&nbsp;");
	printf("<A href=\"http://www.sina.com.cn\" target=_blank>������д��������</A>");
	printf("<script language=\"javascript\" src=\"/Javascript/time.js\"></script>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("</TD></TR></TBODY></TABLE></DIV> ");
	printf("<p>&nbsp;</p>");
	printf("<p>&nbsp;</p>");
	printf("<div align=\"left\"><span class=\"STYLE10\">");
	printf("%s&nbsp;&nbsp;", szCookieName);
	printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳</a></span>&gt;&gt;");
	char *szGet = getenv("QUERY_STRING");
	
	if(NULL == szGet)
	{
		return;
	}
	int flag;                         //Ϊ1������������ӣ� Ϊ0������ظ�����
	char szFlag[10] = {'\0'};
	char szName[256] = {'\0'};
	char szNameDecode[256] = {'\0'};
	char szTitleName[256] = {'\0'};
	char szTitleNameDecode[256] = {'\0'};
	int i = 0;
	sscanf(szGet, "name=%[^'&']", szName);
	i += (6 + strlen(szName));
	sscanf(szGet + i, "flag=%[^'&']", szFlag);
	i += (6 + strlen(szFlag));
	sscanf(szGet + i, "TitleName=%s", szTitleName);
	sscanf(szFlag, "%d", &flag);
	Decode(szName, strlen(szName), szNameDecode);
	Decode(szTitleName, strlen(szTitleName), szTitleNameDecode);
	printf("<span class=\"STYLE10\"><a href=\"/cgi-bin/Title.cgi?name=%s&page=1\">%s</a>", szName, szNameDecode);
	printf("</div>");
	printf("<hr align=\"left\" width=\"1380\" noshade>");

	PrintCore(szNameDecode, szTitleNameDecode, flag);


}
void PrintCore(char *szName, char *szTitleName, int flag)
{
	
    printf("<script language=\"javascript\" src=\"/Javascript/check.js\"></script>");
	printf("<FORM id='leavewordform'  name='leavewordform'action= \"/cgi-bin/SubLeaveword.cgi\" method=\"post\">");
	printf("<table width=\"1384\" height=\"435\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr><td height=\"39\" colspan=\"2\" bgcolor=\"#0066FF\">��������/�ظ���</td></tr>");
	printf("<tr>");
	printf("<td width=\"168\" rowspan=\"2\" valign=\"top\" bgcolor=\"#00CCFF\">");
	printf("</td>");
	printf("<td width=\"1200\" height=\"65\"><label>���⣺");
	printf("<input name=\"title\" type=\"text\" id=\"title\" size=\"50\" />");                    //�µ�������
	printf("</label></td></tr>");
	printf("<tr>");
	printf("<td width=\"1200\" height=\"269\"><textarea name=\"content\" id=\"content\" cols=\"170\" rows=\"20\"></textarea></td>");
	printf("</tr>");
	printf("<tr><td height=\"60\" colspan=\"2\"><label>");
	printf("<div align=\"center\"> �������ԣ�");
	printf("<input type = \"hidden\" name = \"blockname\" value = \"%s\">", szName);               //�����ǰ����
	printf("<input type = \"hidden\" name = \"TitleName\" value = \"%s\">", szTitleName) ;         //������ԭ����������
	printf("<input type = \"hidden\" name = \"flag\" value = \"%d\">", flag);
	if(1==flag)
	{
	   printf("<input type=\"button\" value=\" ��    �� \" onclick=\"checkTheForm()\"/>");
	}
	else if(0==flag)
	{
       printf("<input type=\"button\" value=\" ��    �� \" onclick=\"checkForm()\"/>");
	}
	printf("<input type=\"reset\" value=\"�����������\" />");
	printf("</div>");
	printf("</label></td>");
	printf("</tr></table>");
	printf("</FORM>");
	

}
void PrintTail()
{
	printf("<p>&nbsp;</p>");
	printf("<p align=\"center\"><img src=\"/Images/ad_tinyos.jpg\" width=\"535\" height=\"79\" /></p>");
	printf("<p align=\"center\">&nbsp;</p>");
	printf("<p align=\"center\">�����ν�:<a href=\"http://www.rupeng.com\" target=\"_blank\">������</a>");
	printf("<a href=\"http://www.csdn.net/\" target=\"_blank\">CSDN.NET</a>");
	printf("<a href=\"http://www.nwnu.edu.cn\" target=\"_blank\">����ʦ����ѧ</a>");
	printf("<a href=\"http://www.gdut.edu.cn/\" target=\"_blank\">�㶫��ҵ��ѧ</a></p>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("<table width=\"1384\" height=\"97\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td height=\"97\" bgcolor=\"#00FFFF\"><div align=\"right\">");
	printf("<p class=\"STYLE1\">");
	printf("<script language=\"javascript\" src=\"/Javascript/time.js\"></script>");
	printf("&nbsp;&nbsp;</p>");
	printf("<p class=\"STYLE1\"><a href=\"/cgi-bin/Forum.cgi\">�����������̳</a>&nbsp;&nbsp;&nbsp;</p>");
	printf("</div></td>");
	printf("</tr></table>");
	printf("</body>");
    printf("<html>");
}

int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <=0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}
       
      
    
  


