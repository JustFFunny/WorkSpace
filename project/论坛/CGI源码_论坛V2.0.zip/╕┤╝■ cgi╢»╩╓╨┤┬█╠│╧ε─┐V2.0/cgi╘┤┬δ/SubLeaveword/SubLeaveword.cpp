// SubLeaveword.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define PAX_SZIE      3
#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){return ;}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;

int main(int argc, char* argv[])
{
	PrintHeader();
	PrintCore();
	PrintTail();
	return 0;
}

int Encode(char *src, int length, char *dest, int lenBuffer)
{
	if(NULL == src || length <= 0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if((*src >= 'a' && *src <= 'z') || (*src >= 'A' && *src <= 'Z') || (*src >= '0' && *src <= '9'))
		{
			*dest = *src;
			src++;
			dest++;
			i++;
		}
		else if(' ' == *src)
		{
			*dest = '+';
			src++;
			dest++;
			i++;
		}
		else
		{
			if(i + 3 < lenBuffer)
			{
				sprintf(dest, "%%%02X", (unsigned  char)(*src));
				src++;
				dest += 3;
				i++;

			}
			else
			{
				return 0;
			}
		}
	}
	*(dest) = '\0';
	return 1;
}

//�ַ�����
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <= 0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}           

//���ӵ����ݿ�
void AllocEnv()
{
	SQLRETURN result;
    SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		exit(1);
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}

void PrintHeader()
{
	printf("Content-type:text/html\n\n");
	printf("<HTML>");
	printf("<HEAD>");
	printf("<TITLE></TITLE>");
	printf("</HEAD>");
	printf("<BODY>");
}

void PrintCore()
{
	int iRecordCount = 0;
	SQLRETURN result;
	char szGetDecode[1024] = {'\0'};
	char szNewTitle[256] = {'\0'};
	char szContent[1024] = {'\0'};
    char szBlockName[256] = {'\0'};
	char szOldTitle[256] = {'\0'};
	char szAuthor[256] = {'\0'};
	char szAuthorDecode[256] = {'\0'};
	int flag;
	char *len = getenv("CONTENT_LENGTH");
    int length ; 
    sscanf(len, "%d", &length);
	char *szGet = (char *)malloc((length + 1)*sizeof(char));
	if(NULL == szGet)
	{
		printf("�������ڴ����ʧ�ܣ�");
		return ;
	}
	fgets(szGet, length + 1, stdin);
	Decode(szGet, strlen(szGet), szGetDecode);
	int i = 0;
	sscanf(szGetDecode, "title=%[^'&']", szNewTitle);
	i += (7 + strlen(szNewTitle));
	sscanf(szGetDecode + i, "content=%[^'&']", szContent);
	i += (9 + strlen(szContent));
	sscanf(szGetDecode + i, "blockname=%[^'&']", szBlockName);
	i += (11 + strlen(szBlockName));
	sscanf(szGetDecode + i, "TitleName=%[^'&']", szOldTitle);
	i += (11 + strlen(szOldTitle));
	sscanf(szGetDecode + i, "flag=%d", &flag);

	char *szGetCookie = getenv("HTTP_COOKIE");
	sscanf(szGetCookie, "name=%[^'\0']", szAuthor);
	Decode(szAuthor, strlen(szAuthor), szAuthorDecode);
	//��ȡ��ǰʱ��
	char szTime[256] = {'\0'};
	SYSTEMTIME syt;
	ZeroMemory(&syt, sizeof(SYSTEMTIME));
	GetLocalTime(&syt);
	sprintf(szTime, "%d-%d-%d %d:%d", syt.wYear, syt.wMonth, syt.wDay, syt.wHour, syt.wMinute);

	char szSqlGetCount[256] = {'\0'};
    char szSqlLeaveword[256] = {'\0'};
	char szSqlTitle[256] = {'\0'};

	AllocEnv();
	//flagΪ1�����������⣬ Ϊ0�����ظ�����
	if(1 == flag)
	{
		sprintf(szSqlTitle, "Insert into T_Title(FtitleName, FsecondBlockName, Fauthor, Ftime) values('%s', '%s', '%s', '%s')",
			    szNewTitle, szBlockName, szAuthorDecode, szTime);
		sprintf(szSqlLeaveword, "Insert into T_Leaveword(Ftitle, Fusername, Ftime, FContent) values('%s', '%s', '%s', '%s')",
			    szNewTitle, szAuthorDecode, szTime, szContent);
		result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
		result = SQLPrepare(hstmt, (SQLCHAR *)szSqlTitle, SQL_NTS);
		CHECKDBSTMTERROR(result, hstmt);
		result = SQLExecute(hstmt);
		CHECKDBSTMTERROR(result, hstmt);
		SQLFreeStmt(hstmt,SQL_CLOSE);
	}
	else
	{
		sprintf(szSqlGetCount,  "Select FTitle from T_Leaveword where FTitle = '%s'", szOldTitle);
		sprintf(szSqlLeaveword, "Insert into T_Leaveword(Ftitle, Fusername, Ftime, FContent) values('%s', '%s', '%s', '%s')",
			     szOldTitle, szAuthorDecode, szTime, szContent);
		result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
		result = SQLPrepare(hstmt, (SQLCHAR *)szSqlGetCount, SQL_NTS);
		CHECKDBSTMTERROR(result, hstmt);
		result = SQLExecute(hstmt);
		while(SQLFetch(hstmt) != SQL_NO_DATA_FOUND)
		{
			iRecordCount++;
		}
		SQLFreeStmt(hstmt,SQL_CLOSE);
	}

	
	result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt, (SQLCHAR *)szSqlLeaveword, SQL_NTS);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLExecute(hstmt);
	CHECKDBSTMTERROR(result, hstmt);
	FreeHandle();
	iRecordCount++;

	//����
	char szNewTitleEncode[256] = {'\0'};
	char szOldTitleEncode[256] = {'\0'};
	char szBlockNameEncode[256] = {'\0'};
	Encode(szNewTitle, strlen(szNewTitle), szNewTitleEncode, 256);
	Encode(szOldTitle, strlen(szOldTitle), szOldTitleEncode, 256);
	Encode(szBlockName, strlen(szBlockName), szBlockNameEncode, 256);

	printf("<div align=\"center\">");
	printf("<table width=\"429\" height=\"82\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td width=\"425\" height=\"29\" align=\"center\" valign=\"middle\" bgcolor=\"#FFFFCC\"><span class=\"STYLE2\">");
	printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;�����ɹ���1��󽫻�ת����Ӧҳ��...</span></td>");
	printf("</tr><tr>");
	printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
	if(1 == flag)
	{
		printf("<a href=\"/cgi-bin/Marking.cgi?name=%s&page=1&ModuleName=%s\" class=\"STYLE2\">", szNewTitleEncode, szBlockNameEncode);
		printf("<meta http-equiv=\"refresh\" content=\"1; url=/cgi-bin/Marking.cgi?name=%s&page=1&ModuleName=%s\"></meta>", 
				szNewTitleEncode, szBlockNameEncode);
	}
	else
	{
		int count = iRecordCount/PAX_SZIE;
		if(count*PAX_SZIE < iRecordCount)
		{
			count++;
		}
        printf("<a href=\"/cgi-bin/Marking.cgi?name=%s&page=1&ModuleName=%s\" class=\"STYLE2\">", szOldTitleEncode, szBlockNameEncode);
		printf("<meta http-equiv=\"refresh\" content=\"1; url=/cgi-bin/Marking.cgi?name=%s&page=%d&ModuleName=%s\"></meta>", 
				szOldTitleEncode,  count, szBlockNameEncode);
	}
	printf("������������û���Զ���ת,�������</a></td>");
	printf("</tr>");
	printf("</table>");
	printf("</div>");
}

void PrintTail()
{
	printf("</BODY>");
	printf("</HTML>");
}