
#include "stdafx.h"
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>

#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){ return 0;}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;


//�ַ�����
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <= 0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}

//ע��ɹ�����1�����򷵻�0�� ��ͨ��szInfo���ش�����Ϣ
int Register(char *szInfo)
{
	SQLRETURN result;
	char szUsername[30] = {'\0'};
	char szPassword[20] = {'\0'};
	char szConfimPassword[20] = {'\0'};
	char szSex[10] = {'\0'};
	char szEmail[30] = {'\0'};
	char szEmailPostfix[10] = {'\0'};
	char szQq[15] = {'\0'};
	char szIdentity[20] = {'\0'};
	char szAsk[20] = {'\0'};
	char szQuestion[30] = {'\0'};
	char szSqlInsertUserInfo[256] = {'\0'};
	char szSqlInsertAq[256] = {'\0'};
	char szSqlSearch[256] = {'\0'};

	char *szGetFromUrl = getenv("QUERY_STRING");
	if(NULL == szGetFromUrl)
	{
		strcpy(szInfo, "�ύ��Ϣʧ�ܣ�");
		return 0;
	}
	char szUrlDecode[1024] = {'\0'};
    if(!Decode(szGetFromUrl, strlen(szGetFromUrl), szUrlDecode))
	{
		strcpy(szInfo, "�����������");
		return 0;
	}
	//URL����ȡ���ֶ���Ϣ
	int i = 0;
	int iSex, iIdentity, iAsk;
	sscanf(szUrlDecode, "name=%[^'&']", szUsername);
	i += (strlen(szUsername) + 6);
	sscanf(szUrlDecode + i, "password=%[^'&']", szPassword);
	i += (strlen(szPassword) + 10);
	sscanf(szUrlDecode + i, "repassword=%[^'&']", szConfimPassword);
    i += (strlen(szConfimPassword) + 12);
	sscanf(szUrlDecode + i, "sex=%[^'&']", szSex);
    i += (strlen(szSex) + 5);
	sscanf(szUrlDecode + i, "email=%[^'&']", szEmail);
    i += (strlen(szEmail) + 7);
	sscanf(szUrlDecode + i, "emailPostfix=%[^'&']", szEmailPostfix);
	i += (strlen(szEmailPostfix) + 14);
	sscanf(szUrlDecode + i, "QQ=%[^'&']", szQq);
    i += (strlen(szQq) + 4);
	sscanf(szUrlDecode + i, "identity=%[^'&']", szIdentity);
    i += (strlen(szIdentity) + 10);
	sscanf(szUrlDecode + i, "safety=%[^'&']", szAsk);
    i += (strlen(szAsk) + 8);
	sscanf(szUrlDecode + i, "answer=%[^'\0']", szQuestion);

	iSex = atoi(szSex);
	iIdentity = atoi(szIdentity);
	iAsk = atoi(szAsk);
	
	//�Ȳ�ѯ�û����Ƿ���ڣ�������ھͷ��ؼ���ע��
	sprintf(szSqlSearch, TEXT("select  Fusername from T_UserInfo where Fusername = '%s'"), szUsername);
	AllocEnv();
	//��ʼ�������
    result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt,(SQLCHAR*)szSqlSearch,SQL_NTS);
	CHECKDBSTMTERROR(result,hstmt);
    result =SQLExecute(hstmt);
    CHECKDBSTMTERROR(result,hstmt);
	//�Ѿ����ڴ��û���
	if(SQLFetch(hstmt) != SQL_NO_DATA)
	{
		FreeHandle();
		strcpy(szInfo, "���û����Ѿ����ڣ�������ע�ᣡ");
		return 0;
	}
    //�򵥼���û������Ƿ�Ϸ�
    if(0 == strlen(szUsername) || 0 == strlen(szPassword) || 0 == strlen(szConfimPassword) || 0 == strlen(szEmail))
	{
		strcpy(szInfo, "���ֱ�Ҫ��Ϣδ��ɣ�");
		FreeHandle();
		return 0;
	}

	strcat(szEmail, "@");
	strcat(szEmail, szEmailPostfix);
	//��ȡ��ǰʱ��
	char szTime[256] = {'\0'};
	SYSTEMTIME syt;
	ZeroMemory(&syt, sizeof(SYSTEMTIME));
	GetLocalTime(&syt);
	sprintf(szTime, "%d-%d-%d", syt.wYear, syt.wMonth, syt.wDay);
    sprintf(szSqlInsertUserInfo,TEXT("Insert into T_UserInfo(FUsername, FPassword, FSex, FEmail, FQq, FIdentity, FAsk, FAnswer, FRegistertime)\
		    values('%s','%s', %d, '%s', '%s', %d, %d, '%s', '%s')"), szUsername, szPassword, iSex, szEmail, szQq, 
			iIdentity, iAsk, szQuestion, szTime);
	//��ʼ�������
    result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt,(SQLCHAR*)szSqlInsertUserInfo,SQL_NTS);
	CHECKDBSTMTERROR(result,hstmt);
    result =SQLExecute(hstmt);
    CHECKDBSTMTERROR(result,hstmt);
	FreeHandle();

	return 1;
}

int main()
{
	printf("Content-type:text/html\n\n");
    //��ת����һҳ�棬0������ת����½ҳ��~ 1������ת��ע��ҳ��
    char szInfo[30];
	int iRet = Register(szInfo);

	printf("<html>");
	printf("<head>");
	printf("<title>ע��</title>");
	printf("</head>");
	printf("<body>");
	printf("<p align = 'center'>");
	printf("<br>");
	printf("<div align=\"center\">");
	printf("<table width=\"429\" height=\"82\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td width=\"425\" height=\"29\" align=\"center\" valign=\"middle\" bgcolor=\"#FFFFCC\"><span class=\"STYLE2\">");
	if(1 == iRet)
	{
		printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;ע��ɹ�,3�����ת����¼ҳ��...</span></td>");
		printf("</tr><tr>");
		printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
		printf("<a href=\"/Forum/Load.html\" class=\"STYLE2\">");
        printf("<meta http-equiv=\"refresh\" content=\"3; url=/Forum/Load.html\"></meta>");
	}
	else
	{
		printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;%s<br>3�����ת��ע��ҳ��...</span></td>", szInfo);
		printf("</tr><tr>");
		printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
		printf("<a href=\"/Forum/Register.html\" class=\"STYLE2\">");
		printf("<meta http-equiv=\"refresh\" content=\"3; url=/Forum/Register.html\"></meta>");

	}
	printf("������������û���Զ���ת,�������</a></td>");
	printf("</tr>");
	printf("</table>");
	printf("</div>");
	printf("</p>");
	printf("</body>");
	printf("</html>");
	return 0;
}

//���ӵ����ݿ�
void AllocEnv()
{
	SQLRETURN result;
    SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		exit(1);
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}
