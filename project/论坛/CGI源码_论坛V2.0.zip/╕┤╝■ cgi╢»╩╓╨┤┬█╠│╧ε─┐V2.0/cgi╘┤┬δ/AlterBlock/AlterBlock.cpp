// AddUser.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>

#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){return;}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;
SQLRETURN result;

int main(int argc, char* argv[])
{
	printf("Content-type:text ml\n\n");
	PrintHeader();
	PrintCore();
	PrintTail();
	return 0;
}

void PrintHeader()
{
	printf("<html>");
	printf("<head>");
	printf("<title>");
	printf("</title>");
	printf("<body>");
}

void PrintCore()
{
	SQLINTEGER sqli = SQL_NTS;

	char *szGet = getenv("QUERY_STRING");
    if(NULL == szGet)
	{
		return;
	}
	char szGetDecode[512] = {'\0'};
	char szOldname[30] = {'\0'};
	char szNewname[30] = {'\0'};
	char szAddmaster[10] = {'\0'};
	int iAddmaster;                                     //�Ƿ����ð��
	char szMastername[30] = {'\0'};

	char szSqlSearchBlock[256] = {'\0'};
	char szSqlSearchMaster[256] = {'\0'};
    char szSqlUpdate[256] = {'\0'};
	int i = 0;

	Decode(szGet, strlen(szGet), szGetDecode);
	sscanf(szGetDecode, "oldname=%[^'&']", szOldname);
	i += (9 + strlen(szOldname));
	sscanf(szGetDecode + i, "newname=%[^'&']", szNewname);
	i += (9 + strlen(szNewname));
	sscanf(szGetDecode + i, "addmaster=%[^'&']", szAddmaster);
	i += (11 + strlen(szAddmaster));
	sscanf(szGetDecode + i, "mastername=%[^'\0']", szMastername);
	iAddmaster = atoi(szAddmaster);

	printf("<div align=\"center\">");
	printf("<table width=\"429\" height=\"82\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td width=\"425\" height=\"29\" align=\"center\" valign=\"middle\" bgcolor=\"#FFFFCC\"><span class=\"STYLE2\">");

    sprintf(szSqlSearchBlock, "Select FSecondBlockName from T_SecondBlock where FSecondBlockName = '%s'", szOldname);
	AllocEnv();
	result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLPrepare(hstmt, (SQLCHAR *)szSqlSearchBlock, SQL_NTS);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLExecute(hstmt);
	CHECKDBSTMTERROR(result, hstmt);
	if(SQL_NO_DATA_FOUND == SQLFetch(hstmt))
	{
		FreeHandle();
		printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;<br>�˰�鲻����...</span></td>");
		printf("</tr><tr>");
		printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
		printf("<a href=\"/cgi-bin/Manage.cgi\" class=\"STYLE2\">");
		printf("<meta http-equiv=\"refresh\" content=\"1; url=/cgi-bin/Manage.cgi\"></meta>");
		printf("������������û���Զ���ת,�������</a></td>");
		printf("</tr>");
		printf("</table>");
		printf("</div>");
		printf("</p>");
		return;
	}
	else
	{
		if(0 == strlen(szNewname))
		{
			printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;<br>�°��������Ϊ��...</span></td>");
		}
		else 
		{
			//iAddmaster Ϊ0��ʾ��������� Ϊ1��ʾ��������
			if(0 == iAddmaster)
			{
				sprintf(szSqlUpdate, "Update T_SecondBlock set FSecondBlockName = '%s' where FSecondBlockName = '%s'", szNewname, szOldname);
				SQLFreeStmt(hstmt,SQL_CLOSE);
				result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
				CHECKDBSTMTERROR(result, hstmt);
				result = SQLPrepare(hstmt, (SQLCHAR *)szSqlUpdate, SQL_NTS);
				CHECKDBSTMTERROR(result, hstmt);
				result = SQLExecute(hstmt);
				CHECKDBSTMTERROR(result, hstmt);
				FreeHandle();
				printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;<br>�����ɹ�...</span></td>");
				printf("</tr><tr>");
				printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
				printf("<a href=\"/cgi-bin/Manage.cgi\" class=\"STYLE2\">");
				printf("<meta http-equiv=\"refresh\" content=\"1; url=/cgi-bin/Manage.cgi\"></meta>");
				printf("������������û���Զ���ת,�������</a></td>");
				printf("</tr>");
				printf("</table>");
				printf("</div>");
				printf("</p>");
				return;
			}
			sprintf(szSqlSearchMaster, "Select FUsername from T_UserInfo where FUsername = '%s'", szMastername);
			SQLFreeStmt(hstmt,SQL_CLOSE);
			result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
			CHECKDBSTMTERROR(result, hstmt);
			result = SQLPrepare(hstmt, (SQLCHAR *)szSqlSearchMaster, SQL_NTS);
			CHECKDBSTMTERROR(result, hstmt);
			result = SQLExecute(hstmt);
			CHECKDBSTMTERROR(result, hstmt);
			//�����û����Ƿ���ڣ�������������Ϊ������ ����ʧ��
			if(SQL_NO_DATA_FOUND == SQLFetch(hstmt))
			{
				FreeHandle();
				printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;<br>���û��������ڣ������������ɹ�...</span></td>");
			}
			else
			{
				sprintf(szSqlUpdate, "Update T_SecondBlock set FSecondBlockName = '%s', FMasterName = '%s' where FSecondBlockName = '%s'",
					    szNewname, szMastername, szOldname);
				SQLFreeStmt(hstmt,SQL_CLOSE);
				result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
				CHECKDBSTMTERROR(result, hstmt);
				result = SQLPrepare(hstmt, (SQLCHAR *)szSqlUpdate, SQL_NTS);
				CHECKDBSTMTERROR(result, hstmt);
				result = SQLExecute(hstmt);
				CHECKDBSTMTERROR(result, hstmt);
				FreeHandle();
				printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;<br>�����ɹ�...</span></td>");
			}
        }
		printf("</tr><tr>");
		printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
		printf("<a href=\"/cgi-bin/Manage.cgi\" class=\"STYLE2\">");
		printf("<meta http-equiv=\"refresh\" content=\"1; url=/cgi-bin/Manage.cgi\"></meta>");
		printf("������������û���Զ���ת,�������</a></td>");
		printf("</tr>");
		printf("</table>");
		printf("</div>");
		printf("</p>");
	}


}

void PrintTail()
{
	printf("</body>");
	printf("</html>");
}

void AllocEnv()
{
	SQLRETURN result;
    SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		exit(1);
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{	
	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}

//�ַ�����
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <=0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}