// ControlPanel.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>

#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){exit(1) ;}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;
SQLRETURN result;

int main(int argc, char* argv[])
{
	printf("Content-type:text/html\n\n");
	PrintHeader();
	PrintTail();
	return 0;
}


void PrintHeader()
{

	printf("<html>");
	printf("<head>");
	printf("<title>�����������̳</title>");
	printf("<style type=\"text/css\">");
	printf("</style>");
    printf("<script type=\"text/javascript\" src=\"/JavaScript/SpryAssets/SpryTabbedPanels.js\">");
	printf("</script>");
	printf("<script type=\"text/javascript\" src=\"/JavaScript/SpryAssets/ater.js\">");
	printf("</script>");

	printf("<link href=\"/Javascript/SpryAssets/SpryTabbedPanels.css\" rel=\"stylesheet\" type=\"text/css\">");
	printf("</head>");
	printf("<body>");
	printf("<div align=\"right\">");
	printf("<p><a href=\"/cgi-bin/Forum.cgi\" ><img src=\"/Images/logo.gif\" width=\"185\" height=\"74\" align=\"left\" border=\"0\"/></a>");
	printf("<a href=\"/cgi-bin/Forum.cgi\"><img src=\"/Images/www.jpg\" width=\"150\" height=\"91\" border=\"0\"/></a></p>");
	printf("</div>");
	printf("<DIV style=\"LEFT: 11px;  POSITION: absolute;TOP: 125px; width: 1369px;\">");
	printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳</a><br><br>");
	printf("<TABLE cellSpacing=\"0\" cellPadding=\"0\" width=\"1365\" border=\"0\">");
	printf("<TBODY>");
	printf("<TR>");
	printf("<TD width=\"1380\">");
	printf("<hr width=\"1390\" align=\"left\">");
	char *szGetCookie = getenv("HTTP_COOKIE");
	if(NULL == szGetCookie)
	{
		exit(1);
	}
	char szCookieDecode[256] = {'\0'};
	char szName[256] = {'\0'};
	Decode(szGetCookie, strlen(szGetCookie), szCookieDecode);
	sscanf(szCookieDecode, "name=%[^'\0']", szName);
	printf("%s", szName);

	printf("<!--span class=\"STYLE8\">&nbsp;peilw625311</span--><A href=\"http://www.google.com\" target=_blank>��վ���û�������&nbsp;&nbsp;</A>");
	printf("<A href=\"http://www.163.com\" target=_blank>��������&nbsp;&nbsp;</A>");
	printf("<A href=\"http://www.hao123.com\" target=_blank>��������&nbsp;&nbsp;</A>");
	printf("<script language=\"javascript\" src=\"/Javascript/time.js\">");
	printf("</script>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("</TD>");
	printf("</TR></TBODY></TABLE></DIV>");
	printf("<p>&nbsp;</p>");
	printf("<p>&nbsp;</p>");
	printf("<table width=\"1390\" border=\"0\">");
	printf("<tr>");
	printf("<td height=\"28\" bgcolor=\"#0099FF\"><h2>�༭��������</h2></td>");
	printf("</tr>");
	printf("<td bgcolor=\"#00FFFF\">");
	printf("<div id=\"TabbedPanels1\" class=\"TabbedPanels\">");
	printf("<ul class=\"TabbedPanelsTabGroup\">");
	printf("<li class=\"TabbedPanelsTab\" tabindex=\"0\">��̳��¼</li>");
	printf("<li class=\"TabbedPanelsTab\" tabindex=\"0\">��������</li>");
	printf("<li class=\"TabbedPanelsTab\" tabindex=\"0\">��չ����</li>");
	printf("</ul>");
	printf("<div class=\"TabbedPanelsContentGroup\">");
	printf("<div class=\"TabbedPanelsContent\">");

	PrintCore(szName);
}


void PrintCore(char *szUsername)
{
	SQLINTEGER sqli = SQL_NTS;
	char szSqlSearch[512] = {'\0'};
	char szEmail[30] = {'\0'};
	char szAsk[10] = {'\0'};
	int iAsk;
	char szAnswer[30] = {'\0'};
	char szNickname[30] = {'\0'};
	char szHonor[30] = {'\0'};
	char szSex[10] = {'\0'};
	int iSex;
	char szBirthday[20] = {'\0'};
	char szFrom[30] = {'\0'};
	char szWebsite[30] = {'\0'};
	char szQq[20] = {'\0'};
	char szIcq[20] = {'\0'};
	char szYahoo[30] = {'\0'};
	char szMsn[30] = {'\0'};
	char szWangwang[30] = {'\0'};
	char szZhifubao[30] = {'\0'};
	char szIdentity[10] = {'\0'};
	int iIdentity;
	char szSchool[30] = {'\0'};
	char szSpeciality[30] = {'\0'};

	sprintf(szSqlSearch, "select FEmail, FAsk, FAnswer, FNickName, FHonor, FSex, FBirthday, FFrom, FWebsite,FQq, FIcq, FYahoo, "
		     "FMsn, FWangwang, FZhifubao, FIdentity, FSchool, FSpeciality from T_UserInfo where FUsername = '%s'", szUsername);

	AllocEnv();
    result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt,(SQLCHAR*)szSqlSearch,SQL_NTS);
	CHECKDBSTMTERROR(result,hstmt);
    result =SQLExecute(hstmt);
    CHECKDBSTMTERROR(result,hstmt);
	if(SQL_NO_DATA == SQLFetch(hstmt))
	{
	    FreeHandle();
		exit(1);
	}
	SQLGetData(hstmt, 1, SQL_C_CHAR, szEmail, 30, &sqli);
	SQLGetData(hstmt, 2, SQL_C_CHAR, szAsk, 10, &sqli);
	SQLGetData(hstmt, 3, SQL_C_CHAR, szAnswer, 30, &sqli);
	SQLGetData(hstmt, 4, SQL_C_CHAR, szNickname, 30, &sqli);
	SQLGetData(hstmt, 5, SQL_C_CHAR, szHonor, 30, &sqli);
	SQLGetData(hstmt, 6, SQL_C_CHAR, szSex, 10, &sqli);
	SQLGetData(hstmt, 7, SQL_C_CHAR, szBirthday, 20, &sqli);
	SQLGetData(hstmt, 8, SQL_C_CHAR, szFrom, 30, &sqli);
	SQLGetData(hstmt, 9, SQL_C_CHAR, szWebsite, 30, &sqli);
	SQLGetData(hstmt, 10, SQL_C_CHAR, szQq, 20, &sqli);
	SQLGetData(hstmt, 11, SQL_C_CHAR, szIcq, 20, &sqli);
	SQLGetData(hstmt, 12, SQL_C_CHAR, szYahoo, 30, &sqli);
	SQLGetData(hstmt, 13, SQL_C_CHAR, szMsn, 30, &sqli);
	SQLGetData(hstmt, 14, SQL_C_CHAR, szWangwang, 30, &sqli);
	SQLGetData(hstmt, 15, SQL_C_CHAR, szZhifubao, 30, &sqli);
	SQLGetData(hstmt, 16, SQL_C_CHAR, szIdentity, 10, &sqli);
	SQLGetData(hstmt, 17, SQL_C_CHAR, szSchool, 30, &sqli);
	SQLGetData(hstmt, 18, SQL_C_CHAR, szSpeciality, 30, &sqli);

	FreeHandle();
	iAsk = atoi(szAsk);
	iSex = atoi(szSex);
	iIdentity = atoi(szIdentity);


	printf("<form action=\"/cgi-bin/LoadInfo.cgi\" method=\"get\">");
	printf("<table width=\"1377\" height=\"243\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"#88E1FF\">");
	printf("<tr>");
	printf("<td width=\"272\">ԭ����</td>");
	printf("<td width=\"1092\"><input name=\"password\" type=\"password\" id=\"password\" size=\"25\"></td>");
	printf("</tr>");
	printf("<tr>");
	printf("<td>������</td>");
	printf("<td><input name=\"newpassword\" type=\"password\" id=\"newpassword\" size=\"25\"></td>");
	printf("</tr>");
	printf("<tr>");
	printf("<td>ȷ��������</td>");
	printf("<td><input name=\"renewpassword\" type=\"password\" id=\"renewpassword\" size=\"25\"></td>");
	printf("</tr>");
	printf("<tr>");
	printf("<td>Email</td>");
	printf("<td><input name=\"Email\" type=\"text\" value = \"%s\" id=\"Email\" size=\"25\"></td>", szEmail);
	printf("</tr>");
	printf("<tr>");
	printf("<td>��ȫ����</td>");
	printf("<td><select name=\"safety\" id=\"safety\">");
	
	printf("<option value=\"0\" %s>��</option>", (0 == iAsk)?"selected":"");
	printf("<option value=\"1\" %s>��ļ�����?</option>", (1 == iAsk)?"selected":"");
	printf("<option value=\"2\" %s>��Ĵ�ѧ��?</option>", (2 == iAsk)?"selected":"");
	printf("<option value=\"3\" %s>�㸸�׵�������?</option>", (3 == iAsk)?"selected":"");
	printf("<option value=\"4\" %s>���֤��������?</option>", (4 == iAsk)?"selected":"");
	printf("<option value=\"5\" %s>����ϲ������ʦ��?</option>", (5 == iAsk)?"selected":"");
	printf("</select>");
	printf("</td>");
	printf("</tr>");
	printf("<tr>");
	printf("<td>�ش�</td>");
	printf("<td><input name=\"answer\" type=\"text\" value = \"%s\" id=\"answer\" size=\"25\"></td>", szAnswer);
	printf("</tr>");
	printf("<tr>");
	printf("<td>&nbsp;</td>");
	printf("<td><input type=\"submit\"  id=\"button\" value=\"  �ύ  \"></td>");
	printf("</tr>");
	printf("</table>");
	printf("</form>");
	printf("</div>");
	printf("<div class=\"TabbedPanelsContent\">");

	printf("<form action=\"/cgi-bin/BaseInfo.cgi\" method=\"get\">");
	printf("<table width=\"1375\" height=\"451\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"#88E1FF\">");
	printf("<tr>");
	printf("<td width=\"272\">�ǳ�</td>");
	printf("<td width=\"1092\"><input name=\"nickname\" type=\"text\" value = \"%s\" id=\"textfield6\" size=\"25\"></td>",szNickname);
	printf("</tr>");
	printf("<tr>");
	printf("<td>�Զ���ͷ��</td>");
	printf("<td><input name=\"honor\" type=\"text\" value = \"%s\" id=\"textfield7\" size=\"25\"></td>", szHonor);
	printf("</tr>");
	printf("<tr>");
	printf("<td>�Ա�</td>");
	printf("<td><input name=\"sex\" type=\"radio\" id=\"radio\" value=\"1\" %s>��", (1 == iSex)?"checked":"");
	printf("<input type=\"radio\" name=\"sex\" id=\"radio2\" value=\"0\" %s>Ů", (0 == iSex)?"checked":"");
	printf("</tr>");
	printf("<tr>");
	printf("<td>����</td>");
	printf("<td><input name=\"birthday\" type=\"text\" value = \"%s\" id=\"birthday\" size=\"25\"></td>", szBirthday);
	printf("</tr>");
	printf("<tr>");
	printf("<td>����</td>");
	printf("<td><input name=\"from\" type=\"text\" value = \"%s\" id=\"from\" size=\"25\"></td>", szFrom);
	printf("</tr>");
	printf("<tr>");
	printf("<td>������վ</td>");
	printf("<td><input name=\"website\" type=\"text\" value = \"%s\" id=\"textfield10\" size=\"25\"></td>", szWebsite);
	printf("</tr>");
	printf("<tr>");
	printf("<td>QQ</td>");
	printf("<td><input name=\"QQ\" type=\"text\" value = \"%s\" id=\"QQ\" size=\"25\"></td>", szQq);
	printf("</tr>");
	printf("<tr>");
	printf("<td>ICQ</td>");
	printf("<td><input name=\"ICQ\" type=\"text\" value = \"%s\" id=\"ICQ\" size=\"25\"></td>", szIcq);
	printf("</tr>");
	printf("<tr>");
	printf("<td>YaHoo</td>");
	printf("<td><input name=\"YaHoo\" type=\"text\" value = \"%s\" id=\"YaHoo\" size=\"25\"></td>", szYahoo);
	printf("</tr>");
	printf("<tr>");
	printf("<td>MSN</td>");
	printf("<td><input name=\"MSN\" type=\"text\" value = \"%s\" id=\"MSN\" size=\"25\"></td>", szMsn);
	printf("</tr>");
	printf("<tr>");
	printf("<td>��������</td>");
	printf("<td><input type=\"text\" name = \"Wangwang\" value = \"%s\" size=\"25\"></td>", szWangwang);
	printf("</tr>");
	printf("<tr>");
	printf("<td>֧�����˺�</td>");
	printf("<td><input name=\"Zhifubao\" type=\"text\" value = \"%s\" id=\"textfield16\" size=\"25\"></td>", szZhifubao);
	printf("</tr>");
	printf("<tr>");
	printf("<td>&nbsp;</td>");
	printf("<td><input type=\"submit\"  id=\"button2\" value=\"  �ύ  \"></td>");
	printf("</tr>");
	printf("</table>");
	printf("</form>");
	printf("</div>");
	printf("<div class=\"TabbedPanelsContent\">");

	printf("<form action=\"/cgi-bin/ExtendInfo.cgi\" method=\"get\">");
	printf("<table width=\"1375\" height=\"173\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"#88E1FF\">");
	printf("<tr>");
	printf("<td colspan=\"2\">������Ϣ(*Ϊ������)</td>");
	printf("</tr>");
	printf("<tr>");
	printf("<td width=\"272\">����</td>");
	printf("<td width=\"986\"><select name=\"identity\" id=\"identity\">");
	printf("<option value=\"1\" %s>ר��</option>" , (1 == iIdentity)?"selected":"");
	printf("<option value=\"2\" %s>����</option>", (2 == iIdentity)?"selected":"");
	printf("<option value=\"3\" %s>�о���</option>", (3 == iIdentity)?"selected":"");
	printf("<option value=\"4\" %s>��ְ��Ա</option>", (4 == iIdentity)?"selected":"");
	printf("<option value=\"5\" %s>��ҵ</option>", (5 == iIdentity)?"selected":"");
	printf("<option value=\"6\" %s>����</option>", (6 == iIdentity)?"selected":"");
	printf("</select>");
	printf("</td>");
	printf("</tr>");
	printf("<tr>");
	printf("<td>ѧУ</td>");
	printf("<td><input name=\"school\" type=\"text\" value = \"%s\" id=\"textfield\" size=\"25\"></td>", szSchool);
	printf("</tr>");
	printf("<tr>");
	printf("<td>רҵ</td>");
	printf("<td><input name=\"speciality\" type=\"text\" value = \"%s\" id=\"textfield2\" size=\"25\"></td>", szSpeciality);
	printf("</tr>");
	printf("<tr>");
	printf("<td>&nbsp;</td>");
	printf("<td><input type=\"submit\" id=\"button3\" value=\"  �ύ  \"></td>");
	printf("</tr>");
	printf("</table>");
	printf("</form>");
	printf("</div>");
	printf("</div>");
	printf("</div>");
	printf("</td>");
	printf("</tr>");
	printf("</table>");
}


void PrintTail()
{
	printf("<p align=\"center\"><img src=\"/Images/ad_tinyos.jpg\" width=\"535\" height=\"79\" /></p>");
	printf("<p align=\"center\">&nbsp;</p>");
	printf("<p align=\"center\">�����ν�:<a href=\"http://www.rupeng.com\" target=\"_blank\">������</a>");
	printf("<a href=\"http://www.csdn.net/\" target=\"_blank\">CSDN.NET</a> ");
	printf("<a href=\"http://www.nwnu.edu.cn\" target=\"_blank\">����ʦ����ѧ</a>");
	printf("<a href=\"http://www.gdut.edu.cn/\" target=\"_blank\">�㶫��ҵ��ѧ</a></p>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("<table width=\"1384\" height=\"97\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td height=\"97\" bgcolor=\"#00FFFF\"><div align=\"right\">");
	printf("<p class=\"STYLE1\">");
	printf("<script language=\"javascript\" src=\"/Javascript/time.js\">");
	printf("</script>");
	printf("&nbsp;&nbsp;</p>");
	printf("<p class=\"STYLE1\"><a href=\"/cgi-bin/Forum.cgi\">�����������̳</a>&nbsp;&nbsp;&nbsp;</p>");
	printf("</div></td>");
	printf("</tr>");
	printf("</table>");
	printf("<script type=\"text/javascript\">");
    printf("<script type=\"text/javascript\" src=\"/JavaScript/SpryAssets/SpryTabbedPanels.js\">");
	printf("</script>");
	printf("<script type=\"text/javascript\" src=\"/JavaScript/SpryAssets/ater.js\">");
	printf("</script>");
	printf("<!--");
	printf("var TabbedPanels1 = new Spry.Widget.TabbedPanels(\"TabbedPanels1\");");
	printf("//-->");
	printf("</script>");
	printf("</body>");
	printf("</html>");
}


//�ַ�����
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <= 0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}     

//���ݿ�����
void AllocEnv()
{
	SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		return;
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{
	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}

