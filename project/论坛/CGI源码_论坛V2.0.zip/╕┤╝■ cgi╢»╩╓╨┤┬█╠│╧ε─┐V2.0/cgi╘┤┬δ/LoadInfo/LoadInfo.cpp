// LoadInfo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>

#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){ShowDBStmtError(hstmt);return 0;}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;

void ShowDBError(SQLSMALLINT type,SQLHANDLE sqlHandle)
{
    char pStatus[10], pMsg[101];
    SQLSMALLINT SQLmsglen;
    char error[200] = {0};
    SQLINTEGER SQLerr;
    long erg2 = SQLGetDiagRec(type, sqlHandle,1,
		(SQLCHAR *)pStatus,&SQLerr,(SQLCHAR *)pMsg,100,&SQLmsglen);
    wsprintf(error,"%s (%d)\n",pMsg,(int)SQLerr);
    MessageBox(NULL,error,TEXT("ִ�����ݿ����"),MB_ICONERROR|MB_OK);
}
void ShowDBConnError(SQLHDBC hdbc)
{
	ShowDBError(SQL_HANDLE_DBC,hdbc);
}
void ShowDBStmtError(SQLHSTMT hstmt)
{
	ShowDBError(SQL_HANDLE_STMT,hstmt);
}


int main(int argc, char* argv[])
{
	SQLRETURN result;
	SQLINTEGER sqli = SQL_NTS;
	char *szCookie = getenv("HTTP_COOKIE");
	char *szGet = getenv("QUERY_STRING");
	printf("Content-type:text/html\n\n");
	if(NULL == szGet || NULL == szCookie)
	{
		printf("�Ƿ�����\n");
		exit(1);
	}	
	printf("<html>");
	printf("<head>");
	printf("<title></title>");
	printf("</head>");
	printf("<body>");
	char szDecode[512] = {'\0'};
	char szCookieDecode[50] = {'\0'};
	char szUsername[30] = {'\0'};
	char szPassword[50] = {'\0'};
	char szNewPassword[50] = {'\0'};
	char szReNewPassword[50] = {'\0'};
    char szEmail[30] = {'\0'};
	char szSafety[10] = {'\0'};
    int iAsk;
	char szAnswer[50] = {'\0'};
	Decode(szCookie, strlen(szCookie), szCookieDecode);
	Decode(szGet, strlen(szGet), szDecode);
	sscanf(szCookieDecode, "name=%s", szUsername);
	int i = 0;
	sscanf(szDecode, "password=%[^'&']", szPassword);
	i += (10 + strlen(szPassword));
	sscanf(szDecode + i, "newpassword=%[^'&']", szNewPassword);
	i += (13 + strlen(szNewPassword));
	sscanf(szDecode + i, "renewpassword=%[^'&']", szReNewPassword);
	i += (15 + strlen(szReNewPassword));
	sscanf(szDecode + i, "Email=%[^'&']", szEmail);
	i += (7 + strlen(szEmail));
	sscanf(szDecode + i, "safety=%[^'&']", szSafety);
	i += (8 + strlen(szSafety));
	sscanf(szDecode + i, "answer=%[^'\0']", szAnswer);

	iAsk = atoi(szSafety);

	char szSqlSearch[256] = {'\0'};
	char szSqlUpdate[256] = {'\0'};
	char szPasswordFromDb[50] = {'\0'};
	
	sprintf(szSqlSearch, "Select FPassword from T_UserInfo where FUsername = '%s'", szUsername);
	sprintf(szSqlUpdate, "Update T_UserInfo set FPassword = '%s', FEmail = '%s', FAsk = %d, FAnswer = '%s' where FUsername = '%s'",
		    szNewPassword, szEmail, iAsk, szAnswer, szUsername);
	AllocEnv();
    result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt,(SQLCHAR*)szSqlSearch,SQL_NTS);
	CHECKDBSTMTERROR(result,hstmt);
    result =SQLExecute(hstmt);
    CHECKDBSTMTERROR(result,hstmt);	
	if(SQLFetch(hstmt) != SQL_NO_DATA_FOUND)
	{
		SQLGetData(hstmt, 1, SQL_C_CHAR, szPasswordFromDb, 50, &sqli);
		if(strcmp(szPasswordFromDb, szPassword) != 0)
		{
			FreeHandle();
			printf("<p align = 'center'>");
			printf("<br>");
			printf("<div align=\"center\">");
			printf("<table width=\"429\" height=\"82\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
			printf("<tr>");
			printf("<td width=\"425\" height=\"29\" align=\"center\" valign=\"middle\" bgcolor=\"#FFFFCC\"><span class=\"STYLE2\">");
			printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;%s<br>3��󽫷���...</span></td>", "�������벻��ȷ");
			printf("</tr><tr>");
			printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
			printf("<a href=\"/cgi-bin/ControlPanel.cgi\" class=\"STYLE2\">");
			printf("<meta http-equiv=\"refresh\" content=\"3; url=/cgi-bin/ControlPanel.cgi\"></meta>");
			printf("������������û���Զ���ת,�������</a></td>");
			printf("</tr>");
			printf("</table>");
			printf("</div>");
			printf("</p>");
			return -1;
		}
	}
	SQLFreeStmt(hstmt,SQL_CLOSE);
    result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt,(SQLCHAR*)szSqlUpdate,SQL_NTS);
	CHECKDBSTMTERROR(result,hstmt);
    result =SQLExecute(hstmt);
    CHECKDBSTMTERROR(result,hstmt);	
	FreeHandle();
	printf("<meta http-equiv=\"refresh\" content=\"0; url=/cgi-bin/ControlPanel.cgi\"></meta>");
	printf("</body>");
	printf("</html>");

	return 0;
}

//�ַ�����
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <= 0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}

//���ӵ����ݿ�
void AllocEnv()
{
	SQLRETURN result;
    SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		ShowDBConnError(hdbc);
		exit(1);
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}