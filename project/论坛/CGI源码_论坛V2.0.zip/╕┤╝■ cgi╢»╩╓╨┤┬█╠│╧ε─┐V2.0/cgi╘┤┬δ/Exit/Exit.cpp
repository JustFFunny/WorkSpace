// Exit.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

int main(int argc, char* argv[])
{
	//ȡ��cookie��Ϣ
	char *szGetCookie = getenv("HTTP_COOKIE");
	if(NULL == szGetCookie)
	{
		exit(1);
	}
	char szUsername[50] = {'\0'};
	sscanf(szGetCookie, "name=%[^'\0']", szUsername);
	
	//ʹcookieʧЧ
	struct tm *newtime;
	long ltime;
	time( (time_t *) (&ltime) );
	ltime -= 1;
	newtime = gmtime( (time_t *) &ltime);
	printf("Set-Cookie: name=%s; Expires=%s", szUsername, asctime(newtime));

	printf("Content-type:text/html\n\n");
	char *szGet = getenv("QUERY_STRING");
	if(NULL == szGet)
	{
		exit(1);
	}
	char szName[100] = {'\0'};
	char szModuleName[100] = {'\0'};
	char szFlag[10] = {'\0'};
	int flag;
	int i = 0;
	sscanf(szGet, "name=%[^'&']", szName);
	i += (strlen(szName) + 6);
	sscanf(szGet + i, "flag=%[^'&']", szFlag);
	i += (strlen(szFlag) + 6);
	sscanf(szGet + i, "ModuleName=%[^'\0']", szModuleName);
	flag = atoi(szFlag);
	printf("<html>");
	printf("<head>");
	printf("<title>�˳�</title>");
	printf("</head>");
	printf("<body>");
	printf("<p align = 'center'>");
	printf("<br>");
	printf("<div align=\"center\">");
	printf("<table width=\"429\" height=\"82\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td width=\"425\" height=\"29\" align=\"center\" valign=\"middle\" bgcolor=\"#FFFFCC\"><span class=\"STYLE2\">");
	printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;�����ɹ������������ο����ݽ���...</span></td>");
	printf("</tr><tr>");
	printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
	switch(flag)
	{
	case 1:
		{
			printf("<a href=\"/cgi-bin/Forum.cgi\" class=\"STYLE2\">");
			printf("<meta http-equiv=\"refresh\" content=\"1; url=/cgi-bin/Forum.cgi\"></meta>");
		}
		break;
	case 2:
		{
			printf("<a href=\"/cgi-bin/Title.cgi?name=%s&page=1\" class=\"STYLE2\">", szName);
			printf("<meta http-equiv=\"refresh\" content=\"1; url=/cgi-bin/Title.cgi?name=%s&page=1\"></meta>", szName);
		}
		break;
	case 3:
		{
			printf("<a href=\"/cgi-bin/Marking.cgi?name=%s&page=1&ModuleName=%s\" class=\"STYLE2\">", szName, szModuleName);
			printf("<meta http-equiv=\"refresh\" content=\"1; url=/cgi-bin/Marking.cgi?name=%s&page=1&ModuleName=%s\"></meta>", szName, szModuleName);
		}
		break;
	default:
		break;
	}
	printf("������������û���Զ���ת,�������</a></td>");
	printf("</tr>");
	printf("</table>");
	printf("</div>");
	printf("</p>");
	printf("</body>");
	printf("<html>");

	return 0;
}

