// FindPassword.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <stdlib.h>


#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){return 0;}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;
SQLRETURN result;


int main(int argc, char* argv[])
{
	char szInfo[256] = {'\0'};
	int iRet = FindPassword(szInfo);
	printf("Content-type:text/html\n\n");
	printf("<HTML>");
	printf("<HEAD>");
	printf("<TITLE>�һ�����</TITLE>");
	printf("</HEAD>");
	printf("<BODY>");
	printf("<center>");
	printf("<p>");
	if(0 == iRet)
	{
	     printf("%s<br>3���ת���һ�����ҳ��", szInfo);
		 printf("<meta http-equiv=\"refresh\" content=\"3; url=/Forum/FindPassword.html\"></meta>");
	}
	else
	{
		printf("%s<br>", szInfo);
		 printf("<meta http-equiv=\"refresh\" content=\"3; url=/Forum/Load.html\"></meta>");
	}
	printf("<center>");
	printf("</BODY>");
	printf("</HTML>");
	return 0;
}

//���ݿ�����
void AllocEnv()
{
	SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		return;
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{
	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}


//�ַ�����, 0�ǲ��ɹ���1��Ϊ�ɹ�
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <=0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}

//�һ�����
int  FindPassword(char *szInfo)
{
	SQLINTEGER sqli =  SQL_NTS;
	char szGetDecode[1024] = {'\0'};
	char *szGet = getenv("QUERY_STRING");
	if(NULL == szGet)
	{
		strcpy(szInfo, "�ύ��Ϣʧ�ܣ�");
		return 0;
	}
	Decode(szGet, strlen(szGet), szGetDecode);
	
	char szUsernameFromUrl[256] = {'\0'};
	char szEmailFromUrl[256] = {'\0'};
	char szEmailPostfix[256] = {'\0'};
	char szAskFromUrl[10] = {'\0'};
	int iAskFromUrl;
	char szQuestionFromUrl[256] = {'\0'};
	int i = 0;
	sscanf(szGetDecode, "name=%[^'&']", szUsernameFromUrl);
	i += (strlen(szUsernameFromUrl) + 6);
	sscanf(szGetDecode + i, "email=%[^'&']", szEmailFromUrl);
	i += (strlen(szEmailFromUrl) + 7);
	sscanf(szGetDecode + i, "emailpostfix=%[^'&']", szEmailPostfix);
	i += (strlen(szEmailPostfix) + 14);
	sscanf(szGetDecode + i, "safety=%[^'&']", szAskFromUrl);
	i +=(strlen(szAskFromUrl) + 8);
	sscanf(szGetDecode + i, "answer=%[^'\0']", szQuestionFromUrl);

	iAskFromUrl = atoi(szAskFromUrl);
	
	if(0 == strlen(szUsernameFromUrl) || 0 == strlen(szEmailFromUrl) || 0 == strlen(szAskFromUrl) ||0 == strlen(szQuestionFromUrl))
	{
		strcpy(szInfo, "��д��������Ϣ��");
		return 0;
	}
    
	char szSqlSearch[256] = {'\0'};
	char szUsernameFromDb[256] = {'\0'};
	char szPasswordFromDb[256] = {'\0'};
	char szEmailFromDb[256] = {'\0'};
	char szAskFromDb[256] = {'\0'};
	int iAskFromDb;
	char szQuestionFromDb[256] = {'\0'};
	
	strcat(szEmailFromUrl, "@");
	strcat(szEmailFromUrl, szEmailPostfix);
	sprintf(szSqlSearch, "select T_UserInfo.FUsername, FPassword, FEmail, FAsk, FQuestion from T_UserInfo left join "
		"T_Aq on T_UserInfo.FUsername = T_Aq.FUsername where T_UserInfo.FUsername = '%s'",szUsernameFromUrl);
    AllocEnv();
    result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt,(SQLCHAR*)szSqlSearch,SQL_NTS);
	CHECKDBSTMTERROR(result,hstmt);
    result =SQLExecute(hstmt);
    CHECKDBSTMTERROR(result,hstmt);
	if(SQL_NO_DATA_FOUND == SQLFetch(hstmt))
	{
		
		FreeHandle();
        strcpy(szInfo, "��Ϣ����");
		return 0;
	}
	
	SQLGetData(hstmt, 1, SQL_C_CHAR, szUsernameFromDb, 256, &sqli);
	SQLGetData(hstmt, 2, SQL_C_CHAR, szPasswordFromDb, 256, &sqli);
	SQLGetData(hstmt, 3, SQL_C_CHAR, szEmailFromDb, 256, &sqli);
	SQLGetData(hstmt, 4, SQL_C_CHAR, szAskFromDb, 256, &sqli);
	SQLGetData(hstmt, 5, SQL_C_CHAR, szQuestionFromDb, 256, &sqli);
	iAskFromDb = atoi(szAskFromDb);

	if(0 == strcmp(szUsernameFromUrl, szUsernameFromDb) && 0 == strcmp(szEmailFromUrl, szEmailFromDb)&& 
		iAskFromUrl == iAskFromDb && 0 == strcmp(szQuestionFromUrl, szQuestionFromDb))
	{
		strcpy(szInfo, "��֤�ɹ������뽫���������䣬����գ�");
		FreeHandle();
		return 1;
	}
	FreeHandle();
	strcpy(szInfo, "��Ϣ����");	
	return 0;
}
