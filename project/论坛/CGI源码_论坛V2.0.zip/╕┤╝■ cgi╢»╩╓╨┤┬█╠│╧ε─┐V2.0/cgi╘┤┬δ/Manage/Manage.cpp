// Manage.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>

int main(int argc, char* argv[])
{
	printf("Content-type:text/html\n\n");
	PrintHeader();
	PrintCore();
	PrintTail();
	return 0;
}

void PrintHeader()
{
	char *szGetCookie = getenv("HTTP_COOKIE");
	if(NULL == szGetCookie)
	{
		exit(1);
	}
	printf("<html>");
	printf("<head>");
	printf("<title>�����������̳</title>");
	printf("<style type=\"text/css\">");
    printf("<script type=\"text/javascript\" src=\"/JavaScript/SpryAssets/SpryTabbedPanels.js\">");
	printf("</script>");
	printf("<script type=\"text/javascript\" src=\"/JavaScript/SpryAssets/ater.js\">");
	printf("</style>");
	printf("<script src=\"/Javascript/SpryAssets/SpryTabbedPanels.js\" type=\"text/javascript\"></script>");
	printf("<link href=\"/Javascript/SpryAssets/SpryTabbedPanels.css\" rel=\"stylesheet\" type=\"text/css\">");
	printf("<style type=\"text/css\">");
	printf("<!--");
	printf(".STYLE1 {font-size: 14px}");
	printf(".STYLE2 {font-size: 16px}");
	printf(".STYLE4 {");
	printf("font-size: 14px;");
	printf("font-weight: bold;}-->");
	printf("</style>");
	printf("</head>");
	printf("<body onLoad='insertUser()'>");
	printf("<div align=\"right\">");
	printf("<p><a href=\"/cgi-bin/Forum.cgi\" ><img src=\"/Images/logo.gif\" width=\"185\" height=\"74\" align=\"left\" border=\"0\"/></a>");
	printf("<a href=\"/cgi-bin/Forum.cgi\"><img src=\"/Images/www.jpg\" width=\"150\" height=\"91\" border=\"0\"/></a></p>");
	printf("</div>");
	printf("<DIV style=\"LEFT: 11px; POSITION: absolute; TOP: 125px; width: 1369px;\">");
	printf("<TABLE cellSpacing=0 cellPadding=0 width=1365 border=0>");
	printf("<TBODY>");
	printf("<TR>");
	printf("<TD width=\"1380\">");
	printf("<hr width=\"1390\" align=\"left\">");
	printf("����Ա&nbsp;&nbsp;");
	printf("<!--span class=\"STYLE8\">&nbsp;����Ա&nbsp;&nbsp;</span--><A href=\"http://www.google.com\" target=_blank>��վ���û�������&nbsp;&nbsp;</A>");
	printf("<A href=\"http://www.163.com\" target=_blank>��������&nbsp;&nbsp;</A>");
	printf("<A href=\"http://www.hao123.com\" target=_blank>��������&nbsp;&nbsp;</A>");
	printf("<A href=\"http://www.sina.com.cn\" target=_blank>������̳&nbsp;&nbsp;</A>");
	printf("<script language=\"javascript\" src=\"/Javascript/time.js\">");
	printf("</script>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("</TD>");
	printf("</TR></TBODY></TABLE></DIV>");
	printf("<p>&nbsp;</p>");
	printf("<p>&nbsp;</p>");
	printf("<h1>��̳����</h1>");
}

void PrintCore()
{
	printf("<div id=\"TabbedPanels1\" class=\"TabbedPanels\">");
	printf("<ul class=\"TabbedPanelsTabGroup\">");
	printf("<li class=\"TabbedPanelsTab\" tabindex=\"0\">��    ��</li>");
	printf("<li class=\"TabbedPanelsTab\" tabindex=\"0\" onClick=\"AdminFormat()\">��    ��</li>");
	printf("</ul>");
	printf("<div class=\"TabbedPanelsContentGroup\">");
	printf("<div class=\"TabbedPanelsContent\">");
	printf("<table width=\"1359\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"#FFFFFF\" align=\"center\">");
	printf("<tr>");
	printf("<td width=\"107\" height=\"29\" valign=\"top\" bgcolor=\"#33CCFF\"><p>&nbsp;</p>");
	printf("<td width=\"1246\" valign=\"top\" bgcolor=\"#66CCFF\" ><span class=\"STYLE2\">��  ��&gt;&gt;</span>");
	printf("<span id=\"word\">�û�����</span>");
	printf("<script language=\"javascript\" src=\"/JavaScript/Admin.js\">");

	printf("</script></tr><tr>");
	printf("<td height=\"291\" valign=\"top\" bgcolor=\"#33CCFF\">");
	printf("<input type=\"button\" name=\"InsertUser\" id=\"InsertUser\" value=\"  �����û�  \" onClick=\"insertUser()\"><br>");
	printf("<input type=\"button\" name=\"ForbidUser\" id=\"ForbidUser\" value=\"  ��ֹ�û�  \" onClick=\"ForbidUser()\"> ");
	printf("<td width=\"1246\" valign=\"top\" bgcolor=\"#66CCFF\" ><span id=\"see\" ");
	
	printf("</span>");
	printf(" </tr></table></div>");
	printf("<div class=\"TabbedPanelsContent\">");
	printf("<table width=\"1359\" border=\"1\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"#66CCFF\">");
	printf(" <tr>");
	printf("<td width=\"102\" height=\"33\" valign=\"top\"><p>&nbsp;</p>");
	printf("<td width=\"1251\" valign=\"middle\"><span class=\"STYLE2\" >��    ��&gt;&gt;</span><span id=\"format\">������</span> </tr>");
	printf("<script language=\"javascript\" src=\"/JavaScript/Format.js\">");

	printf("</script><tr>");
	printf(" <td height=\"610\" valign=\"top\"><input type=\"button\" name=\"button6\" id=\"button6\" value=\"  ���Ӱ��  \" onClick=\"insertFormat()\"><br>");
	printf("<input type=\"button\" name=\"AdminFormat\" id=\"button8\" value=\"  �������  \" onClick=\"AdminFormat()\"><br>");
	printf("<td width=\"1251\" valign=\"top\"><span id=\"addFormat\">");

	printf("</span>");
	printf("</tr>");
	printf("</table>");
	printf("</div>");
	printf("</div>");
	printf("</div>");
}

void PrintTail()
{
	printf("<p align=\"center\"><img src=\"/Images/ad_tinyos.jpg\" width=\"535\" height=\"79\" /></p>");
	printf("<p align=\"center\">&nbsp;</p>");
	printf("<p align=\"center\">�����ν�:<a href=\"http://www.rupeng.com\" target=\"_blank\">������</a>");
	printf("<a href=\"http://www.csdn.net/\" target=\"_blank\">CSDN.NET</a>");
	printf("<a href=\"http://www.nwnu.edu.cn\" target=\"_blank\">����ʦ����ѧ</a>");
	printf("<a href=\"http://www.gdut.edu.cn/\" target=\"_blank\">�㶫��ҵ��ѧ</a></p>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("<table width=\"1384\" height=\"97\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td height=\"97\" bgcolor=\"#00FFFF\"><div align=\"right\">");
	printf("<p class=\"STYLE1\">");
	printf("<script language=\"javascript\" src=\"/Javascript/time.js\">");
	printf("</script>");
	printf(" &nbsp;&nbsp;</p>");
	printf("<p class=\"STYLE1\"><a href=\"/cgi-bin/Forum.cgi\">�����������̳</a>&nbsp;&nbsp;&nbsp;</p>");
	printf("</div></td>");
	printf("</tr>");
	printf("</table>");
	printf("<script type=\"text/javascript\" src=\"/JavaScript/SpryAssets/SpryTabbedPanels.js\">");
	printf("</script>");
	printf("<script type=\"text/javascript\" src=\"/JavaScript/SpryAssets/ater.js\">");
	printf("</script>");
	printf("</body>");
	printf("</html>");
}


      
    
  







