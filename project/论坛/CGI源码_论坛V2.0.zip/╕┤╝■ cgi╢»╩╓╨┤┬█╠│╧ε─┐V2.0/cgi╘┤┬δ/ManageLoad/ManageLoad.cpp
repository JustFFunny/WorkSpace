// ManageLoad.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>
#include <windows.h>
#include <sql.h>
#include <sqltypes.h>
#include <sqlext.h>

#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){exit(1);}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;
SQLRETURN result;

int main(int argc, char* argv[])
{
	printf("Content-type:text/html\n\n");
	PrintHeader();
	PrintCore();
	PrintTail();
	return 0;
}

void PrintHeader()
{
	printf("<html>");
	printf("<head>");
	printf("<title>�����������̳</title>");
	printf("<style type=\"text/css\">");
	printf("</style>");
	printf("<style type=\"text/css\">");
	printf("<!--");
	printf(".STYLE1 {font-size: 14px}");
	printf(".STYLE5 {");
	printf("font-family: \"����_GB2312\";");
	printf("font-size: 24px;}");
	printf("-->");
	printf("</style>");
	printf("</head>");
	printf("<body>");
	printf("<div align=\"right\">");
	printf("<p><a href=\"/cgi-bin/Forum.cgi\" ><img src=\"/Images/logo.gif\" width=\"185\" height=\"74\" align=\"left\" border=\"0\"/></a>");
	printf("<a href=\"/cgi-bin/Forum.cgi\"><img src=\"/Images/www.jpg\" width=\"150\" height=\"91\" border=\"0\"/></a></p>");
	printf("</div>");
	printf("<DIV style=\"LEFT: 11px; POSITION: absolute; TOP: 125px; width: 1369px;\">");
	printf("<TABLE cellSpacing=0 cellPadding=0 width=1365 border=0>");
	printf("<TBODY>");
	printf("<TR>");
	printf("<TD width=\"1380\">");
	printf("<hr width=\"1390\" align=\"left\">");
	printf("<script language=\"javascript\" src=\"/Javascript/time.js\">");
	printf("</script>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("</TD>");
	printf("</TR></TBODY></TABLE></DIV>");
	printf("<p>&nbsp;</p>");
	printf("<p>&nbsp;</p>");
	printf("<p align=\"left\" class=\"STYLE5\">��̳��������</p>");
	
}
void PrintCore()
{
	SQLINTEGER sqli = SQL_NTS;
	char *szGetCookie = getenv("HTTP_COOKIE");
	if(NULL == szGetCookie)
	{
		PrintError();
		return;
	}
	char szGetCookieDecode[256] = {'\0'};
	char szUsername[30] = {'\0'};
	char szSqlSearch[256] = {'\0'};
	Decode(szGetCookie, strlen(szGetCookie), szGetCookieDecode);
	sprintf(szSqlSearch, "Select FManage from T_UserInfo where FUsername = '%s'", szUsername);
	
	AllocEnv();
	result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt, (SQLCHAR *)szSqlSearch, SQL_NTS);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLExecute(hstmt);
	CHECKDBSTMTERROR(result, hstmt);
	if(0 == SQLFetch(hstmt))
	{
		FreeHandle();
		PrintError();
		return;
	}
	else
	{
		char szManage[10] = {'\0'};
		int iManage;
		SQLGetData(hstmt, 1, SQL_C_CHAR, szManage, 10, &sqli);
		iManage = atoi(szManage);
		if(iManage != 2)
		{
			FreeHandle();
			PrintError();
			return;
		}
		FreeHandle();
	}
	printf("<form  method=\"get\" action=\"/cgi-bin/checkManage.cgi\">");
	printf("<div align=\"center\">�û���");
	printf("<input name=\"username\" type=\"text\" id=\"username\" size=\"25\">");
	printf("<br>");
	printf("�� &nbsp;��");
	printf("<input name=\"password\" type=\"password\" size=\"27\">");
	printf("<br>");
	printf("�� &nbsp;��");
	printf("<select name=\"select\" id=\"select\">");
	printf("<option selected value=\"0\">��</option>");
	printf("<option value = \"1\">��ļ�����?</option>");
	printf("<option value = \"2\">��Ĵ�ѧ��?</option>");
	printf("<option value = \"3\">�㸸�׵�������?</option>");
	printf("<option value = \"4\">���֤��������?</option>");
	printf("<option value = \"5\">����ϲ������ʦ��������?&nbsp;</option>");
	printf("</select>");
	printf("<br>");
	printf("��&nbsp;&nbsp;��");
	printf("<input name=\"answer\" type=\"text\" id=\"answer\" size=\"25\">");
	printf("<br>");
	printf("<input type=\"submit\"  value=\" ��  �� \">");
	printf("</div>");
	printf("</form>");
}
void PrintTail()
{
	printf("<p align=\"center\"><img src=\"/Images/ad_tinyos.jpg\" width=\"535\" height=\"79\" /></p>");
	printf("<p align=\"center\">&nbsp;</p>");
	printf("<p align=\"center\">�����ν�:<a href=\"http://www.rupeng.com\" target=\"_blank\">������</a>");
	printf("<a href=\"http://www.csdn.net/\" target=\"_blank\">CSDN.NET</a>");
	printf("<a href=\"http://www.nwnu.edu.cn\" target=\"_blank\">����ʦ����ѧ</a>");
	printf("<a href=\"http://www.gdut.edu.cn/\" target=\"_blank\">�㶫��ҵ��ѧ</a></p>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("<table width=\"1384\" height=\"97\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td height=\"97\" bgcolor=\"#00FFFF\"><div align=\"right\">");
	printf("<p class=\"STYLE1\">");
	printf("<script language=\"javascript\" src=\"/Javascript/time.js\">");
	printf("</script>");
	printf("&nbsp;&nbsp;</p>");
	printf("<p class=\"STYLE1\"><a href=\"/cgi-bin/Forum.cgi\">�����������̳</a>&nbsp;&nbsp;&nbsp;</p>");
	printf("</div></td>");
	printf("</tr>");
	printf("</table>");
	printf("<script type=\"text/javascript\">");
	printf("<!--");
	printf("var TabbedPanels1 = new Spry.Widget.TabbedPanels(\"TabbedPanels1\");");
	printf("//-->");
	printf("</script>");
	printf("</body>");
	printf("</html>");
}

void PrintError()
{
	printf("<div align=\"center\">");
	printf("<table width=\"429\" height=\"82\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td width=\"425\" height=\"29\" align=\"center\" valign=\"middle\" bgcolor=\"#FFFFCC\"><span class=\"STYLE2\">");
	printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;<br>�����Ƿ�...</span></td>", "�û������������֤����");
	printf("</tr><tr>");
	printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
	printf("<a href=\"/cgi-bin/Forum.cgi\" class=\"STYLE2\">");
	printf("<meta http-equiv=\"refresh\" content=\"3; url=/cgi-bin/Forum.cgi\">");	
	printf("������������û���Զ���ת,�������</a></td>");
	printf("</tr>");
	printf("</table>");
	printf("</div>");
}

//���ݿ�����
void AllocEnv()
{
	SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		return;
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{
	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}

//�ַ�����, 0�ǲ��ɹ���1��Ϊ�ɹ�
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <=0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}         














