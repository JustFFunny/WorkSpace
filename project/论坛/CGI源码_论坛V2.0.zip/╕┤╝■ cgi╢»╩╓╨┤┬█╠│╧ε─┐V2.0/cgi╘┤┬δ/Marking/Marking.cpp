#include "StdAfx.h"
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define PAGE_SIZE 3            //ÿҳ������ʾ������

#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){exit(1);}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;


void PrintHeader();
int PrintCore(char *szTitleNameEncode, char *szTitleName, char *szModuleNameEncode, char *szModuleName, int iCurrentPage);
void PrintTail();
int Encode(char *src, int length, char *dest, int lenBuffer);
int Decode(char *src, int length, char *dest);
int GetMarkingCount(char *szModuleName);


int main()
{
	printf("Content-type:text/html\n\n");
	PrintHeader();
	PrintTail();
	return 0;
}

//���ӵ����ݿ�
void AllocEnv()
{
	SQLRETURN result;
    SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		exit(1);
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}


void PrintHeader()
{
	SQLRETURN result;
	SQLINTEGER sqli = SQL_NTS;
	char szCookieDecode[256] = {'\0'};
	char szName[256] = {'\0'};
	int iCurrentPage;                                               //��ǰѡ�е�ҳ��
	char *szGet = getenv("QUERY_STRING");
	char szGetDecode[1024] = {'\0'};
	char szTitleName[256] = {'\0'};
	char szCurrentPage[10] = {'\0'};
	char szModuleName[256]  = {'\0'};
	int i = 0;
	Decode(szGet, strlen(szGet), szGetDecode);
	sscanf(szGetDecode, "name=%[^'&']", szTitleName);
	i +=  6 + strlen(szTitleName);
	sscanf(szGetDecode + i, "page=%[^'&']", szCurrentPage);
	i += 6 + strlen(szCurrentPage);
	sscanf(szGetDecode + i, "ModuleName=%[^'\0']", szModuleName);
	iCurrentPage = atoi(szCurrentPage);
	char szTitleNameEncode[256] = {'\0'};
	Encode(szTitleName, strlen(szTitleName), szTitleNameEncode, 256);      //������������
	char szModuleNameEncode[512] = {'\0'};
	Encode(szModuleName, strlen(szModuleName), szModuleNameEncode, 512);   //�԰��������

	char *szGetCookie = getenv("HTTP_COOKIE");
	printf("<html>");
    printf("<head>");
	printf("<title>�����������̳</title>");
	printf("<style type=\"text/css\">");
	printf("<!--.STYLE1 {font-size: 14px}.STYLE6 {color: #000000}");
    printf(".STYLE7 {font-size: 16px; font-weight: bold;}.STYLE8 {font-size: 16px}--></style>");
	printf("</head><body>");
	printf("<div align=\"right\">");
	printf("<p><a href=\"/cgi-bin/Forum.cgi\"><img src=\"/Images/logo.gif\" width=\"185\" height=\"74\" align=\"left\"  border=\"0\"/></a><img src=\"/Images/www.jpg\" width=\"150\" height=\"91\" /></p>");
    printf("</div>");
	printf("<DIV style=\"LEFT: 11px; POSITION: absolute; TOP: 125px; width: 1369px;\">");
	printf("<TABLE cellSpacing=0 cellPadding=0 width=1365 border=0>");
	printf("<TBODY><TR><TD width=\"1380\">");
	printf("<hr width=\"1390\" align=\"left\">");
	AllocEnv();
	if(NULL == szGetCookie)
	{
		printf("<A href=\"/Forum/Register.html\" target=_parent>ע��</A>&nbsp;&nbsp;");
	    printf("<A href=\"/Forum/Load.html\" target=_parent>��¼</A>&nbsp;&nbsp;");	
	}
	else
	{
		Decode(szGetCookie, strlen(szGetCookie), szCookieDecode);
		sscanf(szCookieDecode, "name=%[^'\0']", szName);
		char szSqlSearch[256] = {'\0'};
		char szManage[10] = {'\0'};
		int iManage;
		sprintf(szSqlSearch, "Select FManage from T_UserInfo where FUsername = '%s'", szName);
		result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
		result = SQLPrepare(hstmt, (SQLCHAR *)szSqlSearch, SQL_NTS);
		CHECKDBSTMTERROR(result, hstmt);
		result = SQLExecute(hstmt);
		CHECKDBSTMTERROR(result, hstmt);
		if(SQLFetch(hstmt) != SQL_NO_DATA_FOUND)
		{
			SQLGetData(hstmt, 1, SQL_C_CHAR, szManage, 10, &sqli);
			iManage = atoi(szManage);
			if(2 == iManage)
			{
				printf("<A href=\"/cgi-bin/ManageLoad.cgi\" target=_parent>������̳</A>&nbsp;&nbsp;");
			}
		}
		SQLFreeStmt(hstmt,SQL_CLOSE);
		printf("<A href=\"/cgi-bin/ControlPanel.cgi\" target=_parent>�������</A>&nbsp;&nbsp;");
		printf("<A href=\"/cgi-bin/Exit.cgi?name=%s&flag=3&ModuleName=%s\" target=_parent>�˳�</A>&nbsp;&nbsp;", szTitleNameEncode, szModuleNameEncode);
	}
	printf("<A href=\"http://www.google.com\" target=_blank>��վ���û�������</A>&nbsp;&nbsp;");
	printf("<A href=\"http://www.163.com\" target=_blank>��վ���û�������</A>&nbsp;&nbsp;");
	printf("<A href=\"http://www.hao123.com\" target=_blank>��վ���û�������</A>&nbsp;&nbsp;");
	printf("<A href=\"http://www.sina.com.cn\" target=_blank>��վ���û�������</A>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("</TD></TR></TBODY></TABLE></DIV>");
	printf("<p>&nbsp;</p><p>&nbsp;</p>");
	if(NULL == szGetCookie)
	{
		printf("<form method=\"get\" action=\"/cgi-bin/Load.cgi\">");
		printf("<div align=\"left\">");
		printf("�û�����<input name=\"name\" type=\"text\" size=\"15\">");
		printf("���룺<input name=\"password\" type=\"password\"  size=\"15\">");
		printf("<input type=\"submit\" value=\"�� ¼\"></div>");
		printf("</form>");
	}
	else
	{

		printf("%s", szName);
	}

	PrintCore(szTitleNameEncode, szTitleName, szModuleNameEncode, szModuleName, iCurrentPage);
}

int PrintCore(char *szTitleNameEncode, char *szTitleName, char *szModuleNameEncode, char *szModuleName, int iCurrentPage)
{

	int iPageCount;                                                  //��ҳ��
	int iTotalRecord;                                                 //�ܼ�¼��
	SQLRETURN result;
	SQLINTEGER sqli = SQL_NTS;
	int i;

	iTotalRecord = GetMarkingCount(szTitleName);
	iPageCount = iTotalRecord/PAGE_SIZE;
	if(iPageCount*PAGE_SIZE < iTotalRecord)
	{
		iPageCount += 1;
	}

	printf("<div align=\"left\"><span class=\"STYLE10\"><a href=\"/cgi-bin/Forum.cgi\">�����������̳</a></span>&gt;&gt;");
	printf("<span class=\"STYLE10\"><a href=\"/cgi-bin/Title.cgi?name=%s&page=1\">%s</a>&gt;&gt;", szModuleNameEncode, szModuleName);

	if(iPageCount > 1)
	{
		for(i = 1; i < iCurrentPage; i++)
		{
			printf("<a href = \"/cgi-bin/Marking.cgi?name=%s&page=%d&ModuleName=%s\">%d</a>&nbsp;", szTitleNameEncode, i, szModuleNameEncode, i);
		}
		printf("<a href = \"/cgi-bin/Marking.cgi?name=%s&page=%d&ModuleName=%s\"><strong>%d</strong></a>&nbsp;", szTitleNameEncode, i, szModuleNameEncode, i);
		i++;
		for(; i <= iPageCount; i++)
		{
			printf("<a href = \"/cgi-bin/Marking.cgi?name=%s&page=%d&ModuleName=%s\">%d</a>&nbsp;", szTitleNameEncode, i, szModuleNameEncode, i);
		}
	}
	printf("<div align=\"right\"><span class=\"STYLE1\"><span class=\"STYLE12\"><span class=\"STYLE13\">");
	//flagΪ1�򷢱����ӣ� Ϊ0��ظ�
	printf("<a href=\"/cgi-bin/Leaveword.cgi?name=%s&flag=0&TitleName=%s\">�ظ�����</a>&nbsp;&nbsp;", szModuleNameEncode, szTitleNameEncode);
	printf("<a href=\"/cgi-bin/Leaveword.cgi?name=%s&flag=1&TitleName=%s\">��������</a>", szModuleNameEncode, szTitleNameEncode);
	printf("</span>&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></div>");
	printf("<hr align=\"left\" width=\"1380\" noshade>");
	printf("<th bordercolor=\"#0033FF\" bgcolor=\"#33CCFF\">");
	printf("<table width=\"1371\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr><td width=\"1076\" height=\"32\" bgcolor=\"#0066FF\"><h1 class=\"STYLE8\">%s</h1></td>", szTitleName);
	printf("</tr></table>");


	char szSQlSearch[512] = {'\0'};
	if(1 == iCurrentPage || 0 == iCurrentPage)
	{
		sprintf(szSQlSearch, "Select Top %d L.FUserName, L.FTime, L.FContent, U.FIdentity, U.FSchool, U.FSpeciality, U.FSex, "
			    " U.FFrom, U.FRegistertime From T_Leaveword L Left Join T_UserInfo U on L.FUsername = U.FUsername where  "
				" FTitle = '%s' order by  L.FTime ASC",  PAGE_SIZE, szTitleName);
	}

	else
	{
		sprintf(szSQlSearch, "Select Top %d L.FUserName, L.FTime, L.FContent , U.FIdentity, U.FSchool, U.FSpeciality, U.Fsex, "
			   " U.FFrom , U.FRegistertime From T_Leaveword L Left join T_UserInfo U  on  L.FUserName = U.FUsername  where  "
			   " FTitle = '%s' and ��� not in (Select top %d ��� from T_Leaveword where FTitle = '%s'  order by FTime ASC) "
			   "order by FTime ASC", PAGE_SIZE, szTitleName, (iCurrentPage - 1)*PAGE_SIZE, szTitleName);
	}

	result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt, (SQLCHAR *)szSQlSearch, SQL_NTS);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLExecute(hstmt);
	CHECKDBSTMTERROR(result, hstmt);
	char *arrayIdentify[7] = {"", "ר��", "����", "�о���", "��ְ��Ա", "��ҵ", "����"};
	char *arraySex[2] = {"Ů��", "����"}; 
	while(SQLFetch(hstmt) != SQL_NO_DATA_FOUND)
	{	
		char szUsername[30] = {'\0'};
		char szTime[30] = {'\0'};
		char szContent[1024] = {'\0'};
		char szIdentify[20] = {'\0'};
		int iIdentify;
		char szSchool[20] = {'\0'};
		char szSpeciality[20] = {'\0'};
		char szSex[10] = {'\0'};
		int iSex;
		char szFrom[30] = {'\0'};
		char szRegistertime[30] = {'\0'};
		DATE_STRUCT dt;
		SQLGetData(hstmt, 1, SQL_C_CHAR, szUsername, 30, &sqli);
		SQLGetData(hstmt, 2, SQL_C_CHAR, szTime, 30, &sqli);
		SQLGetData(hstmt, 3, SQL_C_CHAR, szContent, 1024, &sqli);
		SQLGetData(hstmt, 4, SQL_C_CHAR, szIdentify, 20, &sqli);
		SQLGetData(hstmt, 5, SQL_C_CHAR, szSchool, 20, &sqli);
		SQLGetData(hstmt, 6, SQL_C_CHAR, szSpeciality, 20, &sqli);
		SQLGetData(hstmt, 7, SQL_C_CHAR, szSex, 10,  &sqli);
		SQLGetData(hstmt, 8, SQL_C_CHAR, szFrom, 30, &sqli);
		SQLGetData(hstmt, 9, SQL_C_TYPE_DATE, &dt, sizeof(DATE_STRUCT), &sqli);

		iIdentify = atoi(szIdentify);
		iSex = atoi(szSex);

		sprintf(szRegistertime, "%d-%d-%d", dt.year, dt.month, dt.day);

		printf("<table width=\"1375\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
		printf("<tr><td width=\"208\" height=\"38\" bgcolor=\"#00CCFF\">%s</td>", szUsername);
		printf("<td width=\"1161\">����ʱ��: %s</td></tr>", szTime);
		printf("<tr><td rowspan=\"2\" align=\"left\" valign=\"top\" bgcolor=\"#00CCFF\">");
		printf("<dl><dt>&nbsp;&nbsp;&nbsp;<img src=\"/Images/60.jpg\"></dt>");
		printf("<dt class=\"STYLE1\">&nbsp;&nbsp;&nbsp;����: %s</dt>", arrayIdentify[iIdentify]);
		printf("<dt class=\"STYLE1\">&nbsp;&nbsp;&nbsp;ѧУ: %s</dt>", szSchool);
		printf("<dt class=\"STYLE1\">&nbsp;&nbsp;&nbsp;רҵ: %s&nbsp;</dt>", szSpeciality);
		printf("<dt class=\"STYLE1\">&nbsp;&nbsp;&nbsp;�Ա�: %s&nbsp;</dt>", arraySex[iSex]);
		printf("<dt class=\"STYLE1\">&nbsp;&nbsp;&nbsp;����: %s&nbsp;</dt>", szFrom);
		printf("<dt class=\"STYLE1\">&nbsp;&nbsp;&nbsp;ע��ʱ��: %s&nbsp;</dt>", szRegistertime);
		printf("</dl></td>");
        printf("<td height=\"374\" align=\"left\" valign=\"top\">");
		printf("%s", szContent);
        printf("</td></tr>");
		printf("<tr>");
		printf("<td>&nbsp;</td> </tr>");
        printf("</table></th>");
	}

    FreeHandle();
	printf(" <div align=\"right\"><span class=\"STYLE1\"><span class=\"STYLE12\"><span class=\"STYLE13\">");
	printf("<a href=\"/cgi-bin/Leaveword.cgi?name=%s&flag=0&TitleName=%s\">�ظ�����</a>&nbsp;&nbsp;", szModuleNameEncode, szTitleNameEncode);
	printf("<a href=\"/cgi-bin/Leaveword.cgi?name=%s&flag=1&TitleName=%s\">��������</a>", szModuleNameEncode, szTitleNameEncode);
	printf("</span>&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></div>");
	return 1;
}

void PrintTail()
{
	printf("<p align=\"center\"><img src=\"/Images/ad_tinyos.jpg\" width=\"535\" height=\"79\" /></p>");
	printf("<p align=\"center\">&nbsp;</p>");
	printf("<p align=\"center\">�����ν�:<a href=\"http://www.rupeng.com\" target=\"_blank\">������</a>");
	printf("<a href=\"http://www.csdn.net/\" target=\"_blank\">CSDN.NET</a>");
	printf("<a href=\"http://www.nwnu.edu.cn\" target=\"_blank\">����ʦ����ѧ</a> ");
	printf("<a href=\"http://www.gdut.edu.cn/\" target=\"_blank\">�㶫��ҵ��ѧ</a></p>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("<table width=\"1384\" height=\"97\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr>");
	printf("<td height=\"97\" bgcolor=\"#00FFFF\"><div align=\"right\">");
	printf(" <p class=\"STYLE1\">&nbsp;&nbsp;</p>");
	printf("<p class=\"STYLE1\"><a href=\"http://127.0.0.1/main1.html\">�����������̳</a>&nbsp;&nbsp;&nbsp;</p>");
	printf("</div></td>");
	printf("</tr>");
	printf("</table>");
	printf("</body>");
	printf("</html>");
}

//��ȡ��Ӧ�����е�������
int GetMarkingCount(char *szTitleName)
{
	int count = 0;
	SQLRETURN result;
	char szSql[256] = {'\0'};
	sprintf(szSql, "Select FTitle from T_Leaveword where FTitle = '%s'", szTitleName);
	result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt, (SQLCHAR *)szSql, SQL_NTS);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLExecute(hstmt);
	while(SQLFetch(hstmt) != SQL_NO_DATA_FOUND)
	{
		count++;
	}
	SQLFreeStmt(hstmt,SQL_CLOSE);
	return count;
}


//�ַ�����
int Encode(char *src, int length, char *dest, int lenBuffer)
{
	if(NULL == src || length <= 0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if((*src >= 'a' && *src <= 'z') || (*src >= 'A' && *src <= 'Z') || (*src >= '0' && *src <= '9'))
		{
			*dest = *src;
			src++;
			dest++;
			i++;
		}
		else if(' ' == *src)
		{
			*dest = '+';
			src++;
			dest++;
			i++;
		}
		else
		{
			if(i + 3 < lenBuffer)
			{
				sprintf(dest, "%%%02X", (unsigned  char)(*src));
				src++;
				dest += 3;
				i++;

			}
			else
			{
				return 0;
			}
		}
	}
	*(dest) = '\0';
	return 1;
}
          
//�ַ�����
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <= 0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}           
      

