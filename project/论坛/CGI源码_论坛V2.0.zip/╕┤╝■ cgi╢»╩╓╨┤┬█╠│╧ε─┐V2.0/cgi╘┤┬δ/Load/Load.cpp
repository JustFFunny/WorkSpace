// Load.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <string.h>
#include <time.h>

#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){return 0;}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;
SQLRETURN result;

int main()
{

	char szInfo[256] = {'\0'};
	int iRet = Load(szInfo);
	printHtml(szInfo, iRet);
	return 0;
}

//���ݿ�����
void AllocEnv()
{
	SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		return;
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{
	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}


 //iRefresh��Ҫ��ת����ҳ�棬 1������ת����̳ҳ�棬0������ת����ת�����µ�½ҳ��
void printHtml(char *szInfo, int iRefresh)
{

	printf("Content-type:text/html\n\n");
	printf("<html>");
	printf("<head>");
	printf("<title>��¼</title>");
	printf("</head>");
	printf("<Body>");
	printf("<p align = 'center'>");
	printf("<br>");
	printf("<div align=\"center\">");
	printf("<table width=\"429\" height=\"82\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td width=\"425\" height=\"29\" align=\"center\" valign=\"middle\" bgcolor=\"#FFFFCC\"><span class=\"STYLE2\">");
	if(1 == iRefresh)
	{
		TCHAR szInfoEncode[256] = {'\0'};	
		if(Encode(szInfo, strlen(szInfo), szInfoEncode, 256))
		{	
			printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;%s ��¼�ɹ�<br>3���ת����̳ҳ��...</span></td>", szInfo);
			printf("</tr><tr>");
			printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
			printf("<a href=\"/cgi-bin/Forum.cgi?name=%s\" class=\"STYLE2\">", szInfoEncode);
			printf("<meta http-equiv=\"refresh\" content=\"3; url=/cgi-bin/Forum.cgi?name=%s\">", szInfoEncode);
		}
		else
		{
			printf("������������⣡");
		}
	}
	else
	{
		printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;%s<br>3�������ת����½ҳ��...</span></td>", szInfo);
		printf("</tr><tr>");
		printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
		printf("<a href=\"/Form/Load.html\" class=\"STYLE2\">");
		printf("<meta http-equiv=\"refresh\" content=\"3; url=/Forum/Load.html\"></meta>");
	}
	printf("������������û���Զ���ת,�������</a></td>");
	printf("</tr>");
	printf("</table>");
	printf("</div>");
	printf("</p>");
	printf("</body>");
	printf("</html>");
}


//����0������¼���ɹ���1���ʾ�ɹ���szInfo������Ӧ����Ϣ
int Load(char *szInfo)
{
	char szUserNameFromUrl[30] = {'\0'};
	char szPasswordFromUrl[30] = {'\0'};
	char szAskFromUrl[30] = {'\0'};
	char szQuestionFromUrl[30] = {'\0'};
    char *szGet = getenv("QUERY_STRING");
	if(NULL == szGet)
	{
		strcpy(szInfo, "�ύ��Ϣʧ��");
		return 0;
		
	}

	char szGetDecode[1024] = {'\0'};
    if(!Decode(szGet, strlen(szGet), szGetDecode))
	{
		strcpy(szInfo, "�����п��ܳ������⣡");
		return 0;
	}
	int i = 0;
	int iAskFromUrl;
    sscanf(szGetDecode, "name=%[^'&']", szUserNameFromUrl);
    i += (strlen(szUserNameFromUrl) + 6); 
	sscanf(szGetDecode + i, "password=%[^'&']", szPasswordFromUrl);
	i += (strlen(szPasswordFromUrl) + 10);
	sscanf(szGetDecode + i, "safety=%[^'&']", szAskFromUrl);
	i += (strlen(szAskFromUrl) + 8);
	sscanf(szGetDecode + i, "answer=%[^'\0']", szQuestionFromUrl);
	
	iAskFromUrl = atoi(szAskFromUrl);
    
	char czSqlSearch[256] = {'\0'};
	char czFindPassword[256] = {'\0'};
	if(0 == strcmp(szUserNameFromUrl, "") || 0 == strcmp(szPasswordFromUrl, ""))
	{
		strcpy(szInfo, "�û��������붼����Ϊ��!");
		return 0;
	}

	sprintf(czSqlSearch,"select FUsername, FPassword, FAsk, FAnswer, FState from T_UserInfo  where FUsername ='%s'", 
		    szUserNameFromUrl);
	char szUserNameFromDb[256] = {'\0'};
	char szPasswordFromDb[256] = {'\0'};
	char szAskFromDb[256] = {'\0'};
	int iAskFromDb;
	char szQuestionFromDb[256] = {'\0'};
	char szState[10] = {'\0'};
	int iState;
	SQLINTEGER sqli = SQL_NTS;
	AllocEnv();
	//��ʼ�������
    result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt,(SQLCHAR*)czSqlSearch,SQL_NTS);
	CHECKDBSTMTERROR(result,hstmt);
    result =SQLExecute(hstmt);
    CHECKDBSTMTERROR(result,hstmt);
	if(SQLFetch(hstmt) != SQL_NO_DATA)
	{
		
		SQLGetData(hstmt, 1, SQL_C_CHAR, szUserNameFromDb,sizeof(szUserNameFromDb)/sizeof(char), &sqli);
		SQLGetData(hstmt, 2, SQL_C_CHAR, szPasswordFromDb,sizeof(szPasswordFromDb)/sizeof(char), &sqli);
		SQLGetData(hstmt, 3, SQL_C_CHAR, szAskFromDb,sizeof(szAskFromDb)/sizeof(char), &sqli);
		SQLGetData(hstmt, 4, SQL_C_CHAR, szQuestionFromDb, sizeof(szQuestionFromDb)/sizeof(char), &sqli);
		SQLGetData(hstmt, 5, SQL_C_CHAR, szState, 10, &sqli);

		iAskFromDb = atoi(szAskFromDb);
		iState = atoi(szState);

		//iSate��ʾ���û�����ֹ����
		if(3 == iState)
		{
			strcpy(szInfo, "���û�����ֹ���ʣ�");
			return 0;
		}
		//���ע��ʱ���谲ȫ�ʴ������ж������Ƿ�ƥ��, ����ֻ��ƥ���û���������
		if(iAskFromDb != 0 && strlen(szQuestionFromDb) != 0 )
		{
			if(0 == strcmp(szQuestionFromDb, szQuestionFromUrl) && iAskFromDb == iAskFromUrl &&
			   0 == strcmp(szUserNameFromDb, szUserNameFromUrl) && 0 == strcmp(szPasswordFromDb, szPasswordFromUrl))
			{
     			strcpy(szInfo, szUserNameFromUrl);
				FreeHandle();
				//����Cookie
				char szCookieName[256] = {'\0'};
				Encode(szUserNameFromUrl, strlen(szUserNameFromUrl), szCookieName, 256);
				long ltime;
				time( (time_t *) &ltime);
				ltime += 24*3600;
				struct tm *newTiem = gmtime( (time_t *) &ltime);
				printf("Set-Cookie: name=%s; expires=%s; secure", szCookieName, asctime(newTiem));
				return 1;
			}
			else
			{
				strcpy(szInfo, "�û��������룬��ȫ��ʾ�䲻ƥ��!");
				FreeHandle();
				return 0;
			}
		}
		else
		{
			if(0 == strcmp(szUserNameFromDb, szUserNameFromUrl) && 0 == strcmp(szPasswordFromDb, szPasswordFromUrl))
			{
				strcpy(szInfo, szUserNameFromUrl);
				FreeHandle();
				//����Cookie
				char szCookieName[256] = {'\0'};
				Encode(szUserNameFromUrl, strlen(szUserNameFromUrl), szCookieName, 256);
				long ltime;
				time( (time_t *) &ltime);
				ltime += 24*3600;
				struct tm *newTiem = gmtime( (time_t *) &ltime);
				printf("Set-Cookie: name=%s; expires=%s; secure", szCookieName, asctime(newTiem));
				return 1;
			}
			else
			{
				strcpy(szInfo, "�û��������벻ƥ�䣡");
				FreeHandle();
				return 0;
			}
		}
	}
	else
	{
		strcpy(szInfo, "���û������ڣ�");
		FreeHandle();
		return 0;
	}
	return 1;
}

//�ַ�����
int Encode(char *src, int length, char *dest, int lenBuffer)
{
	if(NULL == src || length <= 0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if((*src >= 'a' && *src <= 'z') || (*src >= 'A' && *src <= 'Z') || (*src >= '0' && *src <= '9'))
		{
			*dest = *src;
			src++;
			dest++;
			i++;
		}
		else if(' ' == *src)
		{
			*dest = '+';
			src++;
			dest++;
			i++;
		}
		else
		{
			if(i + 3 < lenBuffer)
			{
				sprintf(dest, "%%%02X", (unsigned  char)(*src));
				src++;
				dest += 3;
				i++;

			}
			else
			{
				return 0;
			}
		}
	}
	*(dest) = '\0';
	return 1;
}

//�ַ�����, 0�ǲ��ɹ���1��Ϊ�ɹ�
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <=0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}