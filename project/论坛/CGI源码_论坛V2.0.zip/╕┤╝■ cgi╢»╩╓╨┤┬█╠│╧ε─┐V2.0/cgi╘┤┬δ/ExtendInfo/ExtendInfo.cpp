// BaseInfo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define PAX_SZIE      3
#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){return -1;}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;
int iRecordCount = 0;

int main(int argc, char* argv[])
{
	SQLINTEGER result;
	char *szCookie = getenv("HTTP_COOKIE");
	char *szGet = getenv("QUERY_STRING");
	printf("Content-type:text/html\n\n");
	if(NULL == szCookie || NULL == szGet)
	{
		printf("�Ƿ�����\n");
		return -1;
	}
	char szGetDecode[256] = {'\0'};
	char szCookieDecode[30] = {'\0'};
	char szUsername[30] = {'\0'};
	char szIdentity[20] = {'\0'};
	int iIdentity;
	char szScool[20] = {'\0'};
	char szSpeciality[10] = {'\0'};
	Decode(szCookie, strlen(szCookie), szCookieDecode);
	sscanf(szCookieDecode, "name=%[^'\0']", szUsername);
	Decode(szGet, strlen(szGet), szGetDecode);
	int i = 0;
    sscanf(szGetDecode, "identity=%[^'&']", szIdentity);
	i += (strlen(szIdentity) + 10);
	sscanf(szGetDecode + i, "school=%[^'&']", szScool);
	i += (strlen(szScool) + 8);
	sscanf(szGetDecode + i, "speciality=%[^'\0']", szSpeciality);

	iIdentity = atoi(szIdentity);

	char szSqlUpdate[512] = {'\0'};
	sprintf(szSqlUpdate, "Update T_UserInfo set  FIdentity = %d, FSchool = '%s', FSpeciality = '%s' where FUsername = '%s'",
		     iIdentity, szScool, szSpeciality, szUsername);
	AllocEnv();
	result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLPrepare(hstmt, (SQLCHAR*)szSqlUpdate, SQL_NTS);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLExecute(hstmt);
	CHECKDBSTMTERROR(result, hstmt);
	FreeHandle();
	printf("<html>");
	printf("<head>");
	printf("<title>");
	printf("</title>");
	printf("</head>");
	printf("<body>");
	printf("<meta http-equiv=\"refresh\" content=\"0; url=/cgi-bin/ControlPanel.cgi\"></meta>");
	printf("</body>");
	printf("</html>");

	return 0;
}

//�ַ�����
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <= 0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}           
      

//���ӵ����ݿ�
void AllocEnv()
{
	SQLRETURN result;
    SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		exit(1);
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}