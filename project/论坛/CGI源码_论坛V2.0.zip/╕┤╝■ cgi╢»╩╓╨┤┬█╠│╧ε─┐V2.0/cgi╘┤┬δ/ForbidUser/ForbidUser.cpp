// AddUser.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <time.h>


#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){return;}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;
SQLRETURN result;

int main(int argc, char* argv[])
{
	printf("Content-type:text ml\n\n");
	PrintHeader();
	PrintCore();
	PrintTail();
	return 0;
}

void PrintHeader()
{
	printf("<html>");
	printf("<head>");
	printf("<title>");
	printf("</title>");
	printf("<body>");
}

void PrintCore()
{
	SQLINTEGER sqli = SQL_NTS;
	char *szCookie = getenv("HTTP_COOKIE");
	if(NULL == szCookie)
	{
		return;
	}
	char *szGet = getenv("QUERY_STRING");
    if(NULL == szGet)
	{
		return;
	}
	char szCookieDecode[50] = {'\0'};
	char szCookieName[30] = {'\0'};
	char szGetDecode[512] = {'\0'};
	char szUsername[30] = {'\0'};
	char szState[10] = {'\0'};
	int iState;
	char szDelete[10] = {'\0'};
	int iDelete;
	char szSqlSearch[256] = {'\0'};
	char szSqlUpdate[256] = {'\0'};
	int i = 0;
	Decode(szCookie, strlen(szCookie), szCookieDecode);
	sscanf(szCookieDecode, "name=%[^'\0']", szCookieName);
	Decode(szGet, strlen(szGet), szGetDecode);
	sscanf(szGetDecode, "username=%[^'&']", szUsername);
	i += (strlen(szUsername) + 10);
	sscanf(szGetDecode + i, "type=%[^'&']", szState);
	i += (strlen(szState) + 6);
	sscanf(szGetDecode + i, "delete=%[^'&']", szDelete);
    iState = atoi(szState);
	iDelete = atoi(szDelete);

	printf("<div align=\"center\">");
	printf("<table width=\"429\" height=\"82\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td width=\"425\" height=\"29\" align=\"center\" valign=\"middle\" bgcolor=\"#FFFFCC\"><span class=\"STYLE2\">");
	//��ֹ��ִ���Լ�����
	if(0 == strcmp(szCookieName, szUsername))
	{
		printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;<br>���ܶ��Լ�ִ�в���...</span></td>");
		printf("</tr><tr>");
		printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
		printf("<a href=\"/cgi-bin/Manage.cgi\" class=\"STYLE2\">");
		printf("<meta http-equiv=\"refresh\" content=\"1; url=/cgi-bin/Manage.cgi\"></meta>");
		printf("������������û���Զ���ת,�������</a></td>");
		printf("</tr>");
		printf("</table>");
		printf("</div>");
		printf("</p>");
		return;
	}
    sprintf(szSqlSearch, "Select FUsername from T_UserInfo where FUsername = '%s'", szUsername);
	AllocEnv();
	result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLPrepare(hstmt, (SQLCHAR *)szSqlSearch, SQL_NTS);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLExecute(hstmt);
	CHECKDBSTMTERROR(result, hstmt);
	if(SQLFetch(hstmt) == SQL_NO_DATA_FOUND)
	{
		FreeHandle();
		printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;<br>���û�������...</span></td>");
		printf("</tr><tr>");
		printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
		printf("<a href=\"/cgi-bin/Manage.cgi\" class=\"STYLE2\">");
		printf("<meta http-equiv=\"refresh\" content=\"1; url=/cgi-bin/Manage.cgi\"></meta>");
		printf("������������û���Զ���ת,�������</a></td>");
		printf("</tr>");
		printf("</table>");
		printf("</div>");
		printf("</p>");
		return;
	}
	else
	{
		sprintf(szSqlUpdate, "Update T_UserInfo set FState = %d where FUserName = '%s'", iState, szUsername);
		SQLFreeStmt(hstmt,SQL_CLOSE);
		result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
		CHECKDBSTMTERROR(result, hstmt);
		result = SQLPrepare(hstmt, (SQLCHAR *)szSqlUpdate, SQL_NTS);
		CHECKDBSTMTERROR(result, hstmt);
		result = SQLExecute(hstmt);
		CHECKDBSTMTERROR(result, hstmt);
		if(0 == iDelete)
		{
			FreeHandle();
		}
		else
		{
			char szSqlDelete[256] = {'\0'};
			sprintf(szSqlDelete, "Delete From T_Leaveword where FUsername = '%s'", szUsername);
			SQLFreeStmt(hstmt,SQL_CLOSE);
			result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
			CHECKDBSTMTERROR(result, hstmt);
			result = SQLPrepare(hstmt, (SQLCHAR *)szSqlDelete, SQL_NTS);
			CHECKDBSTMTERROR(result, hstmt);
			result = SQLExecute(hstmt);
			CHECKDBSTMTERROR(result, hstmt);
			FreeHandle();
		}
        printf("<a href=\"/cgi-bin/Forum.cgi\">�����������̳ </a>&gt;&gt;<br>�����ɹ�...</span></td>", szUsername);
		printf("</tr><tr>");
		printf("<td align=\"center\" valign=\"middle\" bgcolor=\"#FFCCFF\">");
		printf("<a href=\"/cgi-bin/Manage.cgi\" class=\"STYLE2\">");
		printf("<meta http-equiv=\"refresh\" content=\"1; url=/cgi-bin/Manage.cgi\"></meta>");
		printf("������������û���Զ���ת,�������</a></td>");
		printf("</tr>");
		printf("</table>");
		printf("</div>");
		printf("</p>");
	}


}

void PrintTail()
{
	printf("</body>");
	printf("</html>");
}

void AllocEnv()
{
	SQLRETURN result;
    SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		exit(1);
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{	
	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}

//�ַ�����
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <=0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}