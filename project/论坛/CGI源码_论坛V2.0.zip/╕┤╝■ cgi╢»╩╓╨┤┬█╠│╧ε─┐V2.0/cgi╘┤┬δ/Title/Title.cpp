#include "StdAfx.h"
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define PAGE_SIZE 3            //ÿҳ������ʾ������

#define LOGIN_TIMEOUT 30
#define MAXBUFLEN 255
#define CHECKDBSTMTERROR(result,hstmt) if(SQL_ERROR==result){exit(1) ;}

SQLHENV henv = NULL;
SQLHDBC hdbc = NULL;
SQLHSTMT hstmt = NULL;


void PrintHeader();
void PrintCore(char *szModuleName, int iCurrentPage, char *szNameEncode);
void PrintTail();
int Encode(char *src, int length, char *dest, int lenBuffer);
int Decode(char *src, int length, char *dest);
int GetMarkingCount(char *szModuleName);


int main()
{
	printf("Content-type:text/html\n\n");
	PrintHeader();
	PrintTail();
	return 0;
}

//���ӵ����ݿ�
void AllocEnv()
{
	SQLRETURN result;
    SQLCHAR ConnStrIn[MAXBUFLEN] = "Driver={Microsoft Access Driver (*.mdb)};Dbq=D:\\htdocs\\phorum\\Forum.mdb;Uid=Admin;Pwd=;";
    SQLCHAR ConnStrOut[MAXBUFLEN];
	//���价�����
    result = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	//���ù�����������
    result = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0);
	//�������Ӿ��
    result = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//������������
    result = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (void*)LOGIN_TIMEOUT, 0);
	//�������ݿ�
    result = SQLDriverConnect(hdbc,NULL,
		ConnStrIn,SQL_NTS,
		ConnStrOut,MAXBUFLEN,
		(SQLSMALLINT *)0,SQL_DRIVER_NOPROMPT);
    if(SQL_ERROR==result)
    {
		exit(1);
    }
}

//�Ͽ����ݿ�����
void FreeHandle()
{
	SQLFreeStmt(hstmt,SQL_CLOSE);
    SQLDisconnect(hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV,henv);
}


void PrintHeader()
{
	char szCookieDecode[256] = {'\0'};
	char szName[256] = {'\0'};
	SQLRETURN result;
	SQLINTEGER sqli = SQL_NTS;
	char *szGetCookie = getenv("HTTP_COOKIE");
	int iCurrentPage;                                               //��ǰѡ�е�ҳ��
	char *szGet = getenv("QUERY_STRING");
	char szGetDecode[256] = {'\0'};
	char szModuleName[256] = {'\0'};
	char szCurrentPage[10] = {'\0'};
	Decode(szGet, strlen(szGet), szGetDecode);
	sscanf(szGetDecode, "name=%[^'&']", szModuleName);
	sscanf(szGetDecode + 6 + strlen(szModuleName), "page=%[^'\0']", szCurrentPage);
	iCurrentPage = atoi(szCurrentPage);
	char szNameEncode[256] = {'\0'};	
	Encode(szModuleName, strlen(szModuleName), szNameEncode, 256);      //�԰��������
	printf("<html>");
    printf("<head>");
	printf("<title>�����������̳</title>");
	printf("<style type=\"text/css\">");
    printf("</style>");
	printf("</head><body>");
	printf("<div align=\"right\">");
	printf("<p><a href=\"/cgi-bin/Forum.cgi\"><img src=\"/Images/logo.gif\" width=\"185\" height=\"74\" align=\"left\"  border=\"0\"/></a><img src=\"/Images/www.jpg\" width=\"150\" height=\"91\" /></p>");
    printf("</div>");
	printf("<DIV style=\"LEFT: 11px; POSITION: absolute; TOP: 125px; width: 1369px;\">");
	printf("<TABLE cellSpacing=0 cellPadding=0 width=1365 border=0>");
	printf("<TBODY><TR><TD width=\"1380\">");
	printf("<hr width=\"1390\" align=\"left\">");
	AllocEnv();
	if(NULL == szGetCookie)
	{
		printf("<A href=\"/Forum/Register.html\" target=_parent>ע��</A>&nbsp;&nbsp;");
		printf("<A href=\"/Forum/Load.html\" target=_parent>��¼</A>&nbsp;&nbsp;");
	}
	else
	{
		Decode(szGetCookie, strlen(szGetCookie), szCookieDecode);
		sscanf(szCookieDecode, "name=%[^'\0']", szName);
		char szSqlSearch[256] = {'\0'};
		char szManage[10] = {'\0'};
		int iManage;
		sprintf(szSqlSearch, "Select FManage from T_UserInfo where FUsername = '%s'", szName);
		result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
		result = SQLPrepare(hstmt, (SQLCHAR *)szSqlSearch, SQL_NTS);
		CHECKDBSTMTERROR(result, hstmt);
		result = SQLExecute(hstmt);
		CHECKDBSTMTERROR(result, hstmt);
		if(SQLFetch(hstmt) != SQL_NO_DATA_FOUND)
		{
			SQLGetData(hstmt, 1, SQL_C_CHAR, szManage, 10, &sqli);
			iManage = atoi(szManage);
			if(2 == iManage)
			{
				printf("<A href=\"/cgi-bin/ManageLoad.cgi\" target=_parent>������̳</A>&nbsp;&nbsp;");
			}
		}
		SQLFreeStmt(hstmt,SQL_CLOSE);
		printf("<A href=\"/cgi-bin/ControlPanel.cgi\" target=_parent>�������</A>&nbsp;&nbsp;");
		printf("<A href=\"/cgi-bin/Exit.cgi?name=%s&flag=2&ModuleName=%s\" target=_parent>�˳�</A>&nbsp;&nbsp;", szNameEncode, "");
	}
	printf("<A href=\"http://www.google.com\" target=_blank>��������</A>&nbsp;&nbsp;");
	printf("<A href=\"http://www.163.com\" target=_blank>��������</A>&nbsp;&nbsp;");
	printf("<A href=\"http://www.hao123.com\" target=_blank>��������</A>&nbsp;&nbsp;");
	printf("<A href=\"http://www.sina.com.cn\" target=_blank>��������</A>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("</TD></TR></TBODY></TABLE></DIV>");
	printf("<p>&nbsp;</p><p>&nbsp;</p>");
	printf("<div align=\"left\">");
	//���Cookie
	if(NULL == szGetCookie)
	{
		printf("<form method=\"get\" action=\"/cgi-bin/Load.cgi\">");
		printf("<div align=\"left\">");
		printf("�û�����<input name=\"name\" type=\"text\" size=\"15\">");
		printf("���룺<input name=\"password\" type=\"password\"  size=\"15\">");
		printf("<input type=\"submit\" value=\"�� ¼\"></div>");
		printf("</form>");
	}
	else
	{
		printf("%s", szName);
	}
	printf("<span class=\"STYLE1\"><span class=\"STYLE8\"><a href=\"/cgi-bin/Forum.cgi\">�����������̳</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></div> ");
	printf("<hr align=\"left\" width=\"1380\" noshade>");

	PrintCore(szModuleName, iCurrentPage, szNameEncode);
}

void PrintCore(char *szModuleName, int iCurrentPage, char *szNameEncode)
{
	SQLRETURN result;
	SQLINTEGER sqli = SQL_NTS;
	int iTotalRecord;                                                 //�ܼ�¼��
	int iPageCount;                                                  //��ҳ��

	iTotalRecord = GetMarkingCount(szModuleName);
	iPageCount = iTotalRecord/PAGE_SIZE;
	if(iPageCount*PAGE_SIZE < iTotalRecord)
	{
		iPageCount += 1;
	}

	printf("<div class=\"pages\">");
    int i;

	if(iPageCount > 1)
	{	
		for(i = 1; i < iCurrentPage; i++)
		{
			printf("<a href = \"/cgi-bin/Title.cgi?name=%s&page=%d\">%d</a>&nbsp;", szNameEncode, i, i);
		}
		printf("<a href = \"/cgi-bin/Title.cgi?name=%s&page=%d\"><strong>%d</strong></a>&nbsp;", szNameEncode, i, i);
		i++;
		for(; i <= iPageCount; i++)
		{
			printf("<a href = \"/cgi-bin/Title.cgi?name=%s&page=%d\">%d</a>&nbsp;", szNameEncode, i, i);
		}
	}
	printf("</div>");	
    printf("<div align=\"right\"><span class=\"STYLE1\"><span class=\"STYLE12\"><span class=\"STYLE13\">");
	//flagΪ1�����������ӣ� Ϊ0������ظ�����
	printf("<a href=\"/cgi-bin/Leaveword.cgi?name=%s&flag=1&TitleName=""\">��������</a></span>&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></div>", szNameEncode);
	printf("<table width=\"1375\" height=\"38\" border=\"0\">");
    printf("<tr>");
	printf("<td width=\"1369\" height=\"34\" bgcolor=\"#0066FF\"><span class=\"STYLE7\">%s</span></td>", szModuleName);
	printf("</tr>");
	printf("</table>");
	printf("<table width=\"1372\"  border=\"1\" cellpadding=\"0\" cellspacing=\"0\" id=\"category_20\" style=\"\" summary=\"category20\">");
	printf("<thead class=\"category\"><tr>");
	printf("<th width=\"953\" bordercolor=\"#0033FF\" bgcolor=\"#33CCFF\"><div align=\"left\">&nbsp;&nbsp;����</div></th>");
	printf("<td width=\"123\" bordercolor=\"#0033FF\" bgcolor=\"#33CCFF\" class=\"nums STYLE6\">����</td>");
	printf("<td width=\"78\" bordercolor=\"#0033FF\" bgcolor=\"#33CCFF\" class=\"nums STYLE6\">�ظ�����</td>");
	printf("<td width=\"217\" bordercolor=\"#0033FF\" bgcolor=\"#33CCFF\" class=\"lastpost STYLE6\"><div align=\"right\">��󷢱�</div></td>");
	printf("</tr>");

	char szSQlSearch[512] = {'\0'};
	if(1 == iCurrentPage || 0 == iCurrentPage)
	{
        sprintf(szSQlSearch, "select Top %d T.FTitleName, T.FAuthor, T.FTime, count(L.FUsername), Max(L.FTime) from T_Title T Left join "
			     " T_Leaveword L on T.FTitleName = L.FTitle  where T.FsecondBlockName ='%s' group by T.FAuthor, T.FTitleName , T.FTime "
				 " order by T.FTime ASC", PAGE_SIZE, szModuleName);
	}
	else 
	{
        sprintf(szSQlSearch, "select Top %d T.FTitleName, T.FAuthor, T.FTime, count(L.FUsername), Max(L.FTime) from T_Title T Left "
			    " join T_Leaveword L on T.FTitleName = L.FTitle  where T.FsecondBlockName  = '%s' and  T.FTitleName not in "
				" (select Top %d FTitleName from  T_Title where FsecondBlockName  = '%s' order by FTime ASC) group by T.FAuthor, "
				" T.FTitleName, T.FTime order by T.FTime ASC" , PAGE_SIZE, szModuleName, (iCurrentPage - 1)*PAGE_SIZE, szModuleName);

	}
	result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt, (SQLCHAR *)szSQlSearch, SQL_NTS);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLExecute(hstmt);
	CHECKDBSTMTERROR(result, hstmt);
	while(SQLFetch(hstmt) != SQL_NO_DATA_FOUND)
	{	
		char szTitleName[50] = {'\0'};
		char szAuthor[50] = {'\0'};
		DATE_STRUCT dtMin;
		char szRelpy[10] = {'\0'};
		int iReply;
		char szDtMax[30] = {'\0'};

		char szTitleNameEncode[256] = {'\0'};
		SQLGetData(hstmt, 1, SQL_C_CHAR, szTitleName, 50, &sqli);
		SQLGetData(hstmt, 2, SQL_C_CHAR, szAuthor, 50, &sqli);
		SQLGetData(hstmt, 3, SQL_C_TYPE_DATE, &dtMin, sizeof(DATE_STRUCT), &sqli);
		SQLGetData(hstmt, 4, SQL_C_CHAR, szRelpy, 10, &sqli);
		SQLGetData(hstmt, 5, SQL_C_CHAR, szDtMax, 30, &sqli);
		iReply = atoi(szRelpy);

		Encode(szTitleName, strlen(szTitleName), szTitleNameEncode, 256);
		printf("<tr>");
		printf("<th bordercolor=\"#0033FF\" bgcolor=\"#33CCFF\"><h4 align=\"left\"><a href=\"/cgi-bin/Marking.cgi?name=%s&page=1&ModuleName=%s\">%s</a></h4></th>", szTitleNameEncode, szNameEncode, szTitleName);
		printf("<td bordercolor=\"#0033FF\" bgcolor=\"#33CCFF\" class=\"nums STYLE6\"><cite>%s</cite><br><em>%d-%d-%d</em></td>", szAuthor, dtMin.year, dtMin.month, dtMin.day);
		printf("<td bordercolor=\"#0033FF\" bgcolor=\"#33CCFF\" class=\"nums STYLE6\">%d</td>", iReply - 1);
		printf("<td bordercolor=\"#0033FF\" bgcolor=\"#33CCFF\" class=\"lastpost STYLE6\">%s</td>", szDtMax);
		printf("</tr>");
	}

    FreeHandle();
	printf("</table>");
    printf("<div align=\"right\"><span class=\"STYLE1\"><span class=\"STYLE12\"><span class=\"STYLE13\">");
	printf("<a href=\"/cgi-bin/Leaveword.cgi?name=%s&flag=1&TitleName=""\">��������</a></span>&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></div>",szNameEncode);
}

void PrintTail()
{
	printf("<form name=\"form1\" method=\"post\" action=\"\">");
	printf("<table width=\"1372\" height=\"61\" border=\"1\" cellpadding\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td height=\"59\"><div align=\"right\"><span class=\"STYLE1\">�鿴:");
	printf("<select name=\"See\" id=\"See\">");
	printf("<option selected>ȫ������</option>");
	printf("<option>һ������������</option>");
	printf("<option>һ������������</option>");
	printf("<option>һ��������������</option>");
	printf("</select>����ʽ:");
	printf("<select name=\"select\" id=\"select\">");
	printf("<option selected>�ظ�ʱ��</option>");
	printf("<option>����ʱ��</option>");
	printf("<option>�ظ�����</option>");
	printf("</select> </span>");
	printf("<select name=\"xu\" id=\"xu\">");
	printf("<option>��������</option>");
	printf("<option>��������</option>");
	printf("</select>");
	printf("<input type=\"submit\" name=\"button\" id=\"button\" value=\"�ύ\">");
	printf("</div></td>");
	printf("</tr>");
	printf("</table></form>");
	printf("<p>&nbsp;</p>");
	printf("<p align=\"center\"><img src=\"/Images/ad_tinyos.jpg\" width=\"535\" height=\"79\" /></p>");
	printf("<p align=\"center\">&nbsp;</p>");
	printf("<p align=\"center\">�����ν�:<a href=\"http://www.rupeng.com\" target=\"_blank\">������</a>");	
	printf("<a href=\"http://www.csdn.net/\" target=\"_blank\">CSDN.NET</a>");
	printf("<a href=\"http://www.nwnu.edu.cn\" target=\"_blank\">����ʦ����ѧ</a> ");
	printf("<a href=\"http://www.gdut.edu.cn/\" target=\"_blank\">�㶫��ҵ��ѧ</a></p>");
	printf("<hr width=\"1380\" align=\"left\">");
	printf("<table width=\"1384\" height=\"97\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">");
	printf("<tr>");
	printf("<td height=\"97\" bgcolor=\"#00FFFF\"><div align=\"right\">");
	printf("<p class=\"STYLE1\">");
	printf(" <script language=\"javascript\" src=\"/Javascript/time.js\"></script>");
	printf("&nbsp;&nbsp;</p>");
	printf("<p class=\"STYLE1\"><a href=\"/cgi-bin/Forum.cgi\">�����������̳</a>&nbsp;&nbsp;&nbsp;</p>");
	printf("</div></td>");
	printf("</tr></table>");
	printf("</body>");
	printf("</html>");
}

//��ȡ��Ӧģ���е�������
int GetMarkingCount(char *szModuleName)
{
	int count = 0;
	SQLRETURN result;
	char szSql[256] = {'\0'};
	sprintf(szSql, "Select FTitleName from T_Title where FSecondBlockName = '%s'", szModuleName);
	result = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);
	result = SQLPrepare(hstmt, (SQLCHAR *)szSql, SQL_NTS);
	CHECKDBSTMTERROR(result, hstmt);
	result = SQLExecute(hstmt);
	while(SQLFetch(hstmt) != SQL_NO_DATA_FOUND)
	{
		count++;
	}
	SQLFreeStmt(hstmt,SQL_CLOSE);
	return count;
}


//�ַ�����
int Encode(char *src, int length, char *dest, int lenBuffer)
{
	if(NULL == src || length <= 0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if((*src >= 'a' && *src <= 'z') || (*src >= 'A' && *src <= 'Z') || (*src >= '0' && *src <= '9'))
		{
			*dest = *src;
			src++;
			dest++;
			i++;
		}
		else if(' ' == *src)
		{
			*dest = '+';
			src++;
			dest++;
			i++;
		}
		else
		{
			if(i + 3 < lenBuffer)
			{
				sprintf(dest, "%%%02X", (unsigned  char)(*src));
				src++;
				dest += 3;
				i++;

			}
			else
			{
				return 0;
			}
		}
	}
	*(dest) = '\0';
	return 1;
}
          
//�ַ�����
int Decode(char *src, int length, char *dest)
{
	if(NULL == src || length <= 0)
	{
		return 0;
	}
	int i = 0;
	while(i < length)
	{
		if('+' == *src)
		{
			*dest = ' ';
			i++;
			src++;
			dest++;
		}
		else if('%' == *src)
		{
			int num;
			if(sscanf(src + 1, "%2x", &num) != 1)
			{
				*dest = '?';
			}
			else
			{
				*dest = num;
			}
			i += 3;
			src += 3;
			dest++;
		}
		else
		{
			*dest = *src;
			i++;
			src++;
			dest++;
		}
	}
	*dest = '\0';
	return 1;
}           

