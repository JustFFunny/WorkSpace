#include "FlipAnimation.h"

FlipAnimation::FlipAnimation(QObject *parent) :
    QGraphicsItemAnimation(parent)
{
}
