#include "ShareManager.h"

ShareManager::ShareManager(QObject *parent) :
    QObject(parent)
{
}
