#ifndef FLIPANIMATION_H
#define FLIPANIMATION_H

#include <QGraphicsItemAnimation>

class FlipAnimation : public QGraphicsItemAnimation
{
    Q_OBJECT
public:
    explicit FlipAnimation(QObject *parent = 0);
    
signals:
    
public slots:
    
};

#endif // FLIPANIMATION_H
