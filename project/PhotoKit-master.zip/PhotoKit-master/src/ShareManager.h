#ifndef SHAREMANAGER_H
#define SHAREMANAGER_H

#include <QObject>

class ShareManager : public QObject
{
    Q_OBJECT
public:
    explicit ShareManager(QObject *parent = 0);
    
signals:
    
public slots:
    
};

#endif // SHAREMANAGER_H
