#include "tcpforwardthread.h"

TcpForwardThread::TcpForwardThread(QObject *parent, QTcpSocket *m_tcpSocket,QByteArray *byteArray) :
    QThread(parent)
{
    this->m_tcpSocket = m_tcpSocket;
    this->byteArray = byteArray;

}

void TcpForwardThread::readMesg(){

    QByteArray qba =  m_tcpSocket->readAll();
    byteArray->append(qba);
}
