
#include <QApplication>
#include <QWidget>
#include <phonon>
#include <pthread.h>
#include <QBuffer>
#include <string.h>
#include <QDebug>

#include "testnet_c.h"


//QByteArray byteArray1;
//QBuffer buffer1(&byteArray1);

//void *haddle1 (void *)
//{
//     char buf[20000];
//     int n,i=0;
//     FILE *fp;
//     buffer1.open(QIODevice::ReadWrite);
//     if((fp=fopen("/home/jyf/Videos/4.rmvb","r+"))==NULL)
//     {
//         perror("error11\n"); exit(1);
//     }
//     do
//     {
//         n=fread(buf,1,20000,fp);
//         qDebug("%d %d\n",n,i);
//         if(n>0)
//         {
//             buffer1.seek(i*20000);
//             i++;
//             buffer1.write(buf,n);
//         }
//         if(feof(fp))
//         {
//             perror("OK\n");
//             break;
//         }
//         memset(buf,0,20000);
//        // sleep(1);
//     }
//     while(1);
//     return 0;
//}

int main(int argc,char **argv)
{
   QApplication app(argc, argv);

   /*
   Phonon::MediaObject *music = Phonon::createPlayer(Phonon::MusicCategory,Phonon::MediaSource("i will be your shelter.mp3"));
   music->play();
   */
   /*
   Phonon::MediaObject *video = Phonon::createPlayer(Phonon::VideoCategory,Phonon::MediaSource("test.rmvb"));
   video->play();
   */

   testnet_c w;
   w.show();


//   app.setApplicationName("VideoPlayer");
//   QWidget *widget=new QWidget;
//   widget->setWindowTitle("Video Player");
//   widget->resize(600,400);
//   Phonon::VideoPlayer *player=new Phonon::VideoPlayer(Phonon::VideoCategory,widget);

//   pthread_t b;
//   pthread_create(&b,NULL,haddle1,NULL);
//   sleep(1);
//   player->load(Phonon::MediaSource(& buffer1));
//   player->play();

//   //sleep(1);
//   widget->show();

   app.exec();





}
