/********************************************************************************
** Form generated from reading UI file 'testnet_c.ui'
**
** Created: Wed Nov 20 16:50:32 2013
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTNET_C_H
#define UI_TESTNET_C_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_testnet_c
{
public:
    QWidget *centralwidget;
    QLineEdit *lineEdit_sendmesg;
    QTextEdit *textEdit_recmesg;
    QPushButton *pushButton_con;
    QPushButton *pushButton_send;
    QWidget *widget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *testnet_c)
    {
        if (testnet_c->objectName().isEmpty())
            testnet_c->setObjectName(QString::fromUtf8("testnet_c"));
        testnet_c->resize(689, 600);
        centralwidget = new QWidget(testnet_c);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        lineEdit_sendmesg = new QLineEdit(centralwidget);
        lineEdit_sendmesg->setObjectName(QString::fromUtf8("lineEdit_sendmesg"));
        lineEdit_sendmesg->setGeometry(QRect(90, 460, 511, 27));
        textEdit_recmesg = new QTextEdit(centralwidget);
        textEdit_recmesg->setObjectName(QString::fromUtf8("textEdit_recmesg"));
        textEdit_recmesg->setGeometry(QRect(90, 390, 511, 61));
        pushButton_con = new QPushButton(centralwidget);
        pushButton_con->setObjectName(QString::fromUtf8("pushButton_con"));
        pushButton_con->setGeometry(QRect(90, 500, 98, 27));
        pushButton_send = new QPushButton(centralwidget);
        pushButton_send->setObjectName(QString::fromUtf8("pushButton_send"));
        pushButton_send->setGeometry(QRect(500, 500, 98, 27));
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(90, 20, 511, 351));
        testnet_c->setCentralWidget(centralwidget);
        menubar = new QMenuBar(testnet_c);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 689, 28));
        testnet_c->setMenuBar(menubar);
        statusbar = new QStatusBar(testnet_c);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        testnet_c->setStatusBar(statusbar);

        retranslateUi(testnet_c);

        QMetaObject::connectSlotsByName(testnet_c);
    } // setupUi

    void retranslateUi(QMainWindow *testnet_c)
    {
        testnet_c->setWindowTitle(QApplication::translate("testnet_c", "MainWindow", 0, QApplication::UnicodeUTF8));
        pushButton_con->setText(QApplication::translate("testnet_c", "Start", 0, QApplication::UnicodeUTF8));
        pushButton_send->setText(QApplication::translate("testnet_c", "Send", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class testnet_c: public Ui_testnet_c {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTNET_C_H
