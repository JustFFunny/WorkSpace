#ifndef TESTNET_C_H
#define TESTNET_C_H

#include <QMainWindow>
#include <QtGui>
#include <QtNetwork>
#include <QWidget>
#include <phonon>
#include <pthread.h>
#include <QBuffer>
#include <string.h>
#include <QDebug>
#include <QBuffer>

#include "tcpforwardthread.h"

namespace Ui {
class testnet_c;
}

class testnet_c : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit testnet_c(QWidget *parent = 0);
    ~testnet_c();

public slots:
    void connectServer();
    void readMesg();
    void sendMesg();
    void play();

    
private:
    Ui::testnet_c *ui;
    Phonon::VideoPlayer *player;
    TcpForwardThread *tft;
};

#endif // TESTNET_C_H
