#ifndef TCPFORWARDTHREAD_H
#define TCPFORWARDTHREAD_H

#include <QThread>
#include <QtNetwork>

class TcpForwardThread : public QThread
{
    Q_OBJECT
public:
    explicit TcpForwardThread(QObject *parent = 0,QTcpSocket *m_tcpSocket = 0, QByteArray *byteArray = 0);

    QTcpSocket *m_tcpSocket;

    QByteArray *byteArray;
    
signals:
    
public slots:

   void readMesg();
    
};

#endif // TCPFORWARDTHREAD_H
