#include "testnet_c.h"
#include "ui_testnet_c.h"

QTcpSocket *m_tcpSocket;

QByteArray byteArray;
QBuffer buffer(&byteArray);

//pthread_t b;
//pthread_create(&b,NULL,haddle,NULL);

//sleep(1);
//void *haddle(void *)
//{
//     do
//     {
//         QByteArray qba =  m_tcpSocket->readAll();
//         byteArray.append(qba);
//     }
//    while(m_tcpSocket->isReadable());
//    return 0;
//}


testnet_c::testnet_c(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::testnet_c)
{
    ui->setupUi(this);

    ui->widget->resize(511,350);
    player=new Phonon::VideoPlayer(Phonon::VideoCategory,ui->widget);
    player->load(Phonon::MediaSource(& buffer));

    this->connect(ui->pushButton_con,SIGNAL(clicked()),this,SLOT(connectServer()));
    this->connect(ui->pushButton_send,SIGNAL(clicked()),this,SLOT(sendMesg()));
}

testnet_c::~testnet_c()
{
    delete ui;
}

void testnet_c::connectServer()
{
    m_tcpSocket = new QTcpSocket(this);
    m_tcpSocket->abort();
    m_tcpSocket->connectToHost("127.0.0.1",6100);
//    tft = new TcpForwardThread(NULL, m_tcpSocket, &byteArray);
//    connect(m_tcpSocket,SIGNAL(readyRead()),tft,SLOT(readMesg()));
    connect(m_tcpSocket,SIGNAL(readyRead()),this,SLOT(readMesg()));
    connect(m_tcpSocket,SIGNAL(readChannelFinished()), this, SLOT(play()));
}

int i = 0;
QString fileName;   //存放文件名
QFile *localFile;  //本地文件
void testnet_c::readMesg() //读取信息
{

   int i = m_tcpSocket->bytesAvailable();

   if(i > 0)
   {
       QByteArray qba =  m_tcpSocket->readAll();
       int q = qba.size();
       byteArray.append(qba);
       int a = buffer.size();

       localFile->write(qba);
   }


//   ui->textEdit_recmesg->clear();
//   qDebug()<<qba;
//   QString ss=QVariant(qba).toString();
//   ui->textEdit_recmesg->setText(ss);

}

void testnet_c::sendMesg() //发送信息
{
    localFile = new QFile("3.mp4");
    if(!localFile->open(QFile::WriteOnly))
    {
        qDebug() << "open file error!";
        return;
    }

    QString ss= ui->lineEdit_sendmesg->text();

    QByteArray byteArray_out;
    byteArray_out.append(ss);
    byteArray_out.append("\n");

    m_tcpSocket->write(byteArray_out);//开始传输数据
    m_tcpSocket->waitForBytesWritten();
    ui->lineEdit_sendmesg->clear();

}

void testnet_c::play()
{
//    if(buffer.size() > 0)
//    {
     localFile->close();
      player->play();
//    }
}
