package com.example.androidforward;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.ServerSocket;
import java.net.Socket;



import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Processor p = new Processor();  
		p.start();
			
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	class Processor extends Thread {  
	    ServerSocket socket = null; 
	    public void run() {  
	        try {  
	        	
	        	System.out.println("开始"); 	        	
	            socket = new ServerSocket(7100); // 在7100端口监听 
	            
		        while(true){  			        			   		            	
	            	System.out.println("前"); 
	            	Socket s = socket.accept();  
	            	
	                InputStream localInputStream = s.getInputStream();	                
	    			InputStreamReader localInputStreamReader = new InputStreamReader(localInputStream);	    			
	    			BufferedReader in = new BufferedReader(localInputStreamReader);
	    			
	                String str;	                
	                str = in.readLine();
	                if(str != null)
	                {
	                	 String filePath = "/sdcard/video/3.mp4";
	                     File file = new File(filePath);	                   
	                     FileInputStream reader = new FileInputStream(file); 

	                     DataOutputStream out = new DataOutputStream(s.getOutputStream()); 
	                     
	                     int bufferSize = 10240; // 20K  
	                     byte[] buf = new byte[bufferSize];  
	                     int read = 0;  
	                     // 将文件输入流 循环 读入 Socket的输出流中  
	                     while ((read = reader.read(buf, 0, buf.length)) != -1) {  
	                         out.write(buf, 0, read);  
	                     }   
	                     out.flush();  
	                     // 一定要加上这句，否则收不到来自服务器端的消息返回  
	                     s.shutdownOutput(); 
	                     
	                     s.close();
	                	
//	                    PrintWriter out = new PrintWriter( new BufferedWriter( new OutputStreamWriter(s.getOutputStream())),true);
//		                out.println("eeeeeeeeeeee");
	                }	    		
	    			System.out.println("eeeeeeeeeeee");		    			
		        } 
	          	            
	        	} catch (Exception e) {	        		
	        		e.printStackTrace(); 	        		
	        	} 
	    }
	}

}
